// src/libCrypto.ts
async function stringToPublicKeyForEncryption(pkeyBase64) {
  try {
    const keyArrayBuffer = base64StringToArrayBuffer(pkeyBase64);
    const key = await window.crypto.subtle.importKey(
      "spki",
      keyArrayBuffer,
      {
        name: "RSA-OAEP",
        hash: "SHA-256"
      },
      true,
      ["encrypt"]
    );
    return key;
  } catch (e) {
    if (e instanceof DOMException) {
      console.log("String for the public key (for encryption) is ill-formed!");
    } else if (e instanceof KeyStringCorrupted) {
      console.log("String for the public key (for encryption) is ill-formed!");
    } else {
      console.log(e);
    }
    throw e;
  }
}
async function stringToPublicKeyForSignature(pkeyBase64) {
  try {
    const keyArrayBuffer = base64StringToArrayBuffer(pkeyBase64);
    const key = await window.crypto.subtle.importKey(
      "spki",
      keyArrayBuffer,
      {
        name: "RSASSA-PKCS1-v1_5",
        hash: "SHA-256"
      },
      true,
      ["verify"]
    );
    return key;
  } catch (e) {
    if (e instanceof DOMException) {
      console.log("String for the public key (for signature verification) is ill-formed!");
    } else if (e instanceof KeyStringCorrupted) {
      console.log("String for the public key (for signature verification) is ill-formed!");
    } else {
      console.log(e);
    }
    throw e;
  }
}
async function stringToPrivateKeyForEncryption(skeyBase64) {
  try {
    const keyArrayBuffer = base64StringToArrayBuffer(skeyBase64);
    const key = await window.crypto.subtle.importKey(
      "pkcs8",
      keyArrayBuffer,
      {
        name: "RSA-OAEP",
        hash: "SHA-256"
      },
      true,
      ["decrypt"]
    );
    return key;
  } catch (e) {
    if (e instanceof DOMException) {
      console.log("String for the private key (for decryption) is ill-formed!");
    } else if (e instanceof KeyStringCorrupted) {
      console.log("String for the private key (for decryption) is ill-formed!");
    } else {
      console.log(e);
    }
    throw e;
  }
}
async function stringToPrivateKeyForSignature(skeyBase64) {
  try {
    const keyArrayBuffer = base64StringToArrayBuffer(skeyBase64);
    const key = await window.crypto.subtle.importKey(
      "pkcs8",
      keyArrayBuffer,
      {
        name: "RSASSA-PKCS1-v1_5",
        hash: "SHA-256"
      },
      true,
      ["sign"]
    );
    return key;
  } catch (e) {
    if (e instanceof DOMException) {
      console.log("String for the private key (for signature) is ill-formed!");
    } else if (e instanceof KeyStringCorrupted) {
      console.log("String for the private key (for signature) is ill-formed!");
    } else {
      console.log(e);
    }
    throw e;
  }
}
async function publicKeyToString(key) {
  const exportedKey = await window.crypto.subtle.exportKey("spki", key);
  return arrayBufferToBase64String(exportedKey);
}
async function privateKeyToString(key) {
  const exportedKey = await window.crypto.subtle.exportKey("pkcs8", key);
  return arrayBufferToBase64String(exportedKey);
}
async function generateAssymetricKeysForEncryption() {
  const keypair = await window.crypto.subtle.generateKey(
    {
      name: "RSA-OAEP",
      modulusLength: 2048,
      publicExponent: new Uint8Array([1, 0, 1]),
      hash: "SHA-256"
    },
    true,
    ["encrypt", "decrypt"]
  );
  return [keypair.publicKey, keypair.privateKey];
}
async function generateAssymetricKeysForSignature() {
  const keypair = await window.crypto.subtle.generateKey(
    {
      name: "RSASSA-PKCS1-v1_5",
      modulusLength: 2048,
      publicExponent: new Uint8Array([1, 0, 1]),
      hash: "SHA-256"
    },
    true,
    ["sign", "verify"]
  );
  return [keypair.publicKey, keypair.privateKey];
}
function generateNonce() {
  const nonceArray = new Uint32Array(1);
  self.crypto.getRandomValues(nonceArray);
  return nonceArray[0].toString();
}
async function encryptWithPublicKey(publicKey, message3) {
  try {
    const messageToArrayBuffer = textToArrayBuffer(message3);
    const cypheredMessageAB = await window.crypto.subtle.encrypt(
      { name: "RSA-OAEP" },
      publicKey,
      messageToArrayBuffer
    );
    return arrayBufferToBase64String(cypheredMessageAB);
  } catch (e) {
    if (e instanceof DOMException) {
      console.log(e);
      console.log("Encryption failed!");
    } else if (e instanceof KeyStringCorrupted) {
      console.log("Public key or message to encrypt is ill-formed");
    } else {
      console.log(e);
    }
    throw e;
  }
}
async function signWithPrivateKey(privateKey, message3) {
  try {
    const messageToArrayBuffer = textToArrayBuffer(message3);
    const signedMessageAB = await window.crypto.subtle.sign(
      "RSASSA-PKCS1-v1_5",
      privateKey,
      messageToArrayBuffer
    );
    return arrayBufferToBase64String(signedMessageAB);
  } catch (e) {
    if (e instanceof DOMException) {
      console.log(e);
      console.log("Signature failed!");
    } else if (e instanceof KeyStringCorrupted) {
      console.log("Private key or message to sign is ill-formed");
    } else {
      console.log(e);
    }
    throw e;
  }
}
async function decryptWithPrivateKey(privateKey, message3) {
  try {
    const decrytpedMessageAB = await window.crypto.subtle.decrypt(
      { name: "RSA-OAEP" },
      privateKey,
      base64StringToArrayBuffer(message3)
    );
    return arrayBufferToText(decrytpedMessageAB);
  } catch (e) {
    if (e instanceof DOMException) {
      console.log("Invalid key, message or algorithm for decryption");
    } else if (e instanceof KeyStringCorrupted) {
      console.log("Private key or message to decrypt is ill-formed");
    } else console.log("Decryption failed");
    throw e;
  }
}
async function verifySignatureWithPublicKey(publicKey, messageInClear2, signedMessage) {
  try {
    const signedToArrayBuffer = base64StringToArrayBuffer(signedMessage);
    const messageInClearToArrayBuffer = textToArrayBuffer(messageInClear2);
    const verified = await window.crypto.subtle.verify(
      "RSASSA-PKCS1-v1_5",
      publicKey,
      signedToArrayBuffer,
      messageInClearToArrayBuffer
    );
    return verified;
  } catch (e) {
    if (e instanceof DOMException) {
      console.log("Invalid key, message or algorithm for signature verification");
    } else if (e instanceof KeyStringCorrupted) {
      console.log("Public key or signed message to verify is ill-formed");
    } else console.log("Decryption failed");
    throw e;
  }
}
async function generateSymetricKey() {
  const key = await window.crypto.subtle.generateKey(
    {
      name: "AES-GCM",
      length: 256
    },
    true,
    ["encrypt", "decrypt"]
  );
  return key;
}
async function symmetricKeyToString(key) {
  const exportedKey = await window.crypto.subtle.exportKey("raw", key);
  return arrayBufferToBase64String(exportedKey);
}
async function stringToSymmetricKey(skeyBase64) {
  try {
    const keyArrayBuffer = base64StringToArrayBuffer(skeyBase64);
    const key = await window.crypto.subtle.importKey(
      "raw",
      keyArrayBuffer,
      "AES-GCM",
      true,
      ["encrypt", "decrypt"]
    );
    return key;
  } catch (e) {
    if (e instanceof DOMException) {
      console.log("String for the symmetric key is ill-formed!");
    } else if (e instanceof KeyStringCorrupted) {
      console.log("String for the symmetric key is ill-formed!");
    } else {
      console.log(e);
    }
    throw e;
  }
}
async function encryptWithSymmetricKey(key, message3) {
  try {
    const messageToArrayBuffer = textToArrayBuffer(message3);
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const ivText = arrayBufferToBase64String(iv);
    const cypheredMessageAB = await window.crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      key,
      messageToArrayBuffer
    );
    return [arrayBufferToBase64String(cypheredMessageAB), ivText];
  } catch (e) {
    if (e instanceof DOMException) {
      console.log(e);
      console.log("Encryption failed!");
    } else if (e instanceof KeyStringCorrupted) {
      console.log("Symmetric key or message to encrypt is ill-formed");
    } else {
      console.log(e);
    }
    throw e;
  }
}
async function decryptWithSymmetricKey(key, message3, initVector) {
  const decodedInitVector = base64StringToArrayBuffer(initVector);
  try {
    const decrytpedMessageAB = await window.crypto.subtle.decrypt(
      { name: "AES-GCM", iv: decodedInitVector },
      key,
      base64StringToArrayBuffer(message3)
    );
    return arrayBufferToText(decrytpedMessageAB);
  } catch (e) {
    if (e instanceof DOMException) {
      console.log("Invalid key, message or algorithm for decryption");
    } else if (e instanceof KeyStringCorrupted) {
      console.log("Symmetric key or message to decrypt is ill-formed");
    } else console.log("Decryption failed");
    throw e;
  }
}
async function hash(text) {
  const text2arrayBuf = textToArrayBuffer(text);
  const hashedArray = await window.crypto.subtle.digest("SHA-256", text2arrayBuf);
  return arrayBufferToBase64String(hashedArray);
}
var KeyStringCorrupted = class extends Error {
};
function arrayBufferToBase64String(arrayBuffer) {
  var byteArray = new Uint8Array(arrayBuffer);
  var byteString = "";
  for (var i = 0; i < byteArray.byteLength; i++) {
    byteString += String.fromCharCode(byteArray[i]);
  }
  return btoa(byteString);
}
function base64StringToArrayBuffer(b64str) {
  try {
    var byteStr = atob(b64str);
    var bytes = new Uint8Array(byteStr.length);
    for (var i = 0; i < byteStr.length; i++) {
      bytes[i] = byteStr.charCodeAt(i);
    }
    return bytes.buffer;
  } catch (e) {
    console.log(`String starting by '${b64str.substring(0, 10)}' cannot be converted to a valid key or message`);
    throw new KeyStringCorrupted();
  }
}
function textToArrayBuffer(str) {
  var buf = encodeURIComponent(str);
  var bufView = new Uint8Array(buf.length);
  for (var i = 0; i < buf.length; i++) {
    bufView[i] = buf.charCodeAt(i);
  }
  return bufView;
}
function arrayBufferToText(arrayBuffer) {
  var byteArray = new Uint8Array(arrayBuffer);
  var str = "";
  for (var i = 0; i < byteArray.byteLength; i++) {
    str += String.fromCharCode(byteArray[i]);
  }
  return decodeURIComponent(str);
}

// src/serverMessages.ts
var CasUserName = class {
  constructor(username) {
    this.username = username;
  }
};
var HistoryRequest = class {
  constructor(agentName, index) {
    this.agentName = agentName;
    this.index = index;
  }
};
var HistoryAnswer = class {
  constructor(success, failureMessage, index, allMessages) {
    this.success = success;
    this.failureMessage = failureMessage;
    this.index = index;
    this.allMessages = allMessages;
  }
};
var FilterRequest = class {
  constructor(from, to, indexmin) {
    this.from = from;
    this.to = to;
    this.indexmin = indexmin;
  }
};
var FilteredMessage = class {
  constructor(message3, index, deleted, deleter) {
    this.message = message3;
    this.index = index;
    this.deleted = deleted;
    this.deleter = deleter;
  }
};
var FilteringAnswer = class {
  constructor(success, failureMessage, allMessages) {
    this.success = success;
    this.failureMessage = failureMessage;
    this.allMessages = allMessages;
  }
};
var SendResult = class {
  constructor(success, errorMessage) {
    this.success = success;
    this.errorMessage = errorMessage;
  }
};
var ExtMessage = class {
  constructor(sender, receiver2, content) {
    this.sender = sender;
    this.receiver = receiver2;
    this.content = content;
  }
};
var DeletingRequest = class {
  constructor(indexToDelete) {
    this.indexToDelete = indexToDelete;
  }
};
var DeletingAnswer = class {
  constructor(success, message3) {
    this.success = success;
  }
};
var KeyRequest = class {
  constructor(ownerOfTheKey, publicKey, encryption) {
    this.ownerOfTheKey = ownerOfTheKey;
    this.publicKey = publicKey;
    this.encryption = encryption;
  }
};
var KeyResult = class {
  constructor(success, key, errorMessage) {
    this.success = success;
    this.key = key;
    this.errorMessage = errorMessage;
  }
};

// src/messenger.ts
if (!window.isSecureContext) alert("Not secure context!");
var lastIndexInHistory = 0;
var userButtonLabel = document.getElementById("user-name");
var sendButton = document.getElementById("send-button");
var receiver = document.getElementById("receiver");
var message2 = document.getElementById("message");
var received_messages = document.getElementById("exchanged-messages");
var receiveNounce = false;
var nouceGlobal = "";
var currentNouce = "";
var confirmationNouce = "";
function clearingMessages() {
  received_messages.textContent = "";
}
function stringToHTML(str) {
  var div_elt = document.createElement("div");
  div_elt.innerHTML = str;
  return div_elt;
}
function addingReceivedMessage(message3) {
  received_messages.append(stringToHTML("<p></p><p></p>" + message3));
}
var globalUserName = "";
async function fetchCasName() {
  const urlParams = new URLSearchParams(window.location.search);
  const namerequest = await fetch("/getuser?" + urlParams, {
    method: "GET",
    headers: {
      "Content-type": "application/json; charset=UTF-8"
    }
  });
  if (!namerequest.ok) {
    throw new Error(`Error! status: ${namerequest.status}`);
  }
  const nameResult = await namerequest.json();
  return nameResult.username;
}
async function setCasName() {
  globalUserName = await fetchCasName();
  userButtonLabel.textContent = globalUserName;
}
setCasName();
function getOwnerName() {
  const path = window.location.pathname;
  const name = path.split("/", 2)[1];
  return name;
}
var ownerName = getOwnerName();
async function fetchKey(user2, publicKey, encryption) {
  const keyRequestMessage = new KeyRequest(user2, publicKey, encryption);
  const urlParams = new URLSearchParams(window.location.search);
  const keyrequest = await fetch("/getKey?" + urlParams, {
    method: "POST",
    body: JSON.stringify(keyRequestMessage),
    headers: {
      "Content-type": "application/json; charset=UTF-8"
    }
  });
  if (!keyrequest.ok) {
    throw new Error(`Error! status: ${keyrequest.status}`);
  }
  const keyResult = await keyrequest.json();
  if (!keyResult.success) alert(keyResult.errorMessage);
  else {
    if (publicKey && encryption) return await stringToPublicKeyForEncryption(keyResult.key);
    else if (!publicKey && encryption) return await stringToPrivateKeyForEncryption(keyResult.key);
    else if (publicKey && !encryption) return await stringToPublicKeyForSignature(keyResult.key);
    else if (!publicKey && !encryption) return await stringToPrivateKeyForSignature(keyResult.key);
  }
}
async function sendMessage(agentName, receiverName, messageContent2) {
  try {
    let messageToSend = new ExtMessage(agentName, receiverName, messageContent2);
    const urlParams = new URLSearchParams(window.location.search);
    const request = await fetch("/sendingMessage/" + ownerName + "?" + urlParams, {
      method: "POST",
      body: JSON.stringify(messageToSend),
      headers: {
        "Content-type": "application/json; charset=UTF-8"
      }
    });
    if (!request.ok) {
      throw new Error(`Error! status: ${request.status}`);
    }
    return await request.json();
  } catch (error) {
    if (error instanceof Error) {
      console.log("error message: ", error.message);
      return new SendResult(false, error.message);
    } else {
      console.log("unexpected error: ", error);
      return new SendResult(false, "An unexpected error occurred");
    }
  }
}
async function refresh() {
  try {
    const user2 = globalUserName;
    const historyRequest = new HistoryRequest(user2, lastIndexInHistory);
    const urlParams = new URLSearchParams(window.location.search);
    const request = await fetch(
      "/history/" + ownerName + "?" + urlParams,
      {
        method: "POST",
        body: JSON.stringify(historyRequest),
        headers: {
          "Content-type": "application/json; charset=UTF-8"
        }
      }
    );
    if (!request.ok) {
      throw new Error(`Error! status: ${request.status} `);
    }
    const result = await request.json();
    if (!result.success) {
      alert(result.failureMessage);
    } else {
      lastIndexInHistory = result.index;
      if (result.allMessages.length != 0) {
        for (var m of result.allMessages) {
          let [b, type, sender, receiver2, msgContent, nouce, nounceOfReceiver] = await analyseMessage(m);
          if (b && type == 1) {
            currentNouce = generateNonce();
            constructMessage(2, user2, sender, "", currentNouce);
          } else if (b && type == 2) {
            receiveNounce = true, nouceGlobal = nouce;
          } else if (b && verifyNounce(nouce, currentNouce) && type == 3) {
            actionOnMessageOne(sender, receiver2, msgContent), constructMessage(5, user2, sender, "", nounceOfReceiver, "");
          } else if (b && type == 4) {
            console.log("Historic");
            actionOnMessageOne(sender, receiver2, msgContent);
          } else if (b && type == 5 && verifyNounce(nouce, confirmationNouce)) {
            console.log("Confirmation Reception");
          } else console.log("Msg " + m.sender + " -> " + m.receiver + " : " + m.content + " cannot be exploited by " + user2);
        }
      }
    }
  } catch (error) {
    if (error instanceof Error) {
      console.log("error message: ", error.message);
      return error.message;
    } else {
      console.log("unexpected error: ", error);
      return "An unexpected error occurred";
    }
  }
}
var intervalRefresh = setInterval(refresh, 2e3);
sendButton.onclick = async function() {
  console.log("Boutton clicked");
  let agentName = globalUserName;
  let receiverName = receiver.value;
  let i = 0;
  constructMessage(1, agentName, receiverName, "hey", "");
  console.log("Proto 1");
  while (i < 10 && receiveNounce == false) {
    await new Promise((resolve) => setTimeout(resolve, 2e4));
    console.log("Waiting for the nounce");
    i++;
  }
  i = 0;
  if (receiveNounce == true) {
    console.log("Nounce received" + nouceGlobal);
    confirmationNouce = generateNonce();
    constructMessage(3, agentName, receiverName, message2.value, nouceGlobal, confirmationNouce);
    selfSaveHistory(4, agentName, receiverName, message2.value, nouceGlobal);
    console.log("Proto 3");
  }
  i = 0;
  nouceGlobal = "";
  receiveNounce = false;
};
async function selfSaveHistory(messageType, agentName, receiverName, message3, nouce) {
  let contentToEncrypt = JSON.stringify([messageType, agentName, receiverName, message3, nouce]);
  const ka = await fetchKey(agentName, true, true);
  const encryptedMessage = await encryptWithPublicKey(ka, contentToEncrypt);
  const sendResult = await sendMessage(agentName, agentName, encryptedMessage);
  if (!sendResult.success) {
    console.log(sendResult.errorMessage);
  } else {
    console.log("Successfully save!");
  }
}
async function constructMessage(messageType, agentName, receiverName, message3, nouce, confirmationNouce2 = "") {
  let contentToEncrypt = JSON.stringify([messageType, agentName, receiverName, message3, nouce, confirmationNouce2]);
  try {
    const kb = await fetchKey(receiverName, true, true);
    const encryptedMessage = await encryptWithPublicKey(kb, contentToEncrypt);
    const sendResult = await sendMessage(agentName, receiverName, encryptedMessage);
    if (!sendResult.success) console.log(sendResult.errorMessage);
    else {
      console.log("Successfully sent the message!");
    }
  } catch (e) {
    if (e instanceof Error) {
      console.log("error message: ", e.message);
    } else {
      console.log("unexpected error: ", e);
    }
  }
}
function readableTime() {
  const now = /* @__PURE__ */ new Date();
  const hours = now.getHours().toString();
  const minutes = now.getMinutes().toString();
  const seconds = now.getSeconds().toString();
  return `${hours.length === 1 ? "0" + hours : hours}:${minutes.length === 1 ? "0" + minutes : minutes}:${seconds.length === 1 ? "0" + seconds : seconds}`;
}
async function analyseMessage(message) {
  const user = globalUserName;
  try {
    const messageSender = message.sender;
    const messageContent = message.content;
    if (message.receiver !== user) {
      return [false, 0, "", "", "", "", ""];
    } else {
      try {
        const privkey = await fetchKey(user, false, true);
        const messageInClearString = await decryptWithPrivateKey(privkey, messageContent);
        const messageArrayInClear = JSON.parse(messageInClearString);
        const messageTypeInMessage = Number(messageArrayInClear[0]);
        const messageSenderInMessage = messageArrayInClear[1];
        const messageReceiverInMessage = messageArrayInClear[2];
        const messageInClear = messageArrayInClear[3];
        const nouceInMessage = messageArrayInClear[4];
        const confirmationNouceInMessage = messageArrayInClear[5];
        if (messageSenderInMessage == messageSender || messageReceiverInMessage == globalUserName) {
          return [true, messageTypeInMessage, messageSenderInMessage, messageReceiverInMessage, eval("`(${readableTime()}) " + messageInClear + "`"), nouceInMessage, confirmationNouceInMessage];
        } else {
          console.log("Real message sender and message sender name in the message do not coincide");
        }
      } catch (e) {
        console.log("analyseMessage: decryption failed because of " + e);
        return [false, -1, "", "", "", "", ""];
      }
    }
  } catch (e) {
    console.log("analyseMessage: decryption failed because of " + e);
    return [false, 0, "", "", "", "", ""];
  }
}
function actionOnMessageOne(fromA, ToB, messageContent2) {
  const user2 = globalUserName;
  console.log("actionOnMessageOne: " + fromA + " -> " + ToB + " : " + messageContent2);
  if (fromA === user2) {
    console.log("Le message vient de l'utilisateur lui-m\xEAme.");
    const textToAdd = `<font color="blue"> ${fromA} -> ${ToB} : ${messageContent2} </font>`;
    addingReceivedMessage(textToAdd);
  } else {
    console.log("Message venant d'un autre utilisateur.");
    const textToAdd = `${fromA} -> ${ToB} : ${messageContent2} `;
    addingReceivedMessage(textToAdd);
  }
}
function verifyNounce(nounceOfSender, nounceOfReceiver) {
  return Number(nounceOfSender) == Number(nounceOfReceiver);
}
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYkNyeXB0by50cyIsICIuLi9zcmMvc2VydmVyTWVzc2FnZXMudHMiLCAiLi4vc3JjL21lc3Nlbmdlci50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLyogU291cmNlOiBodHRwczovL2dpc3QuZ2l0aHViLmNvbS9ncm91bmRyYWNlL2I1MTQxMDYyYjQ3ZGQ5NmE1YzIxYzkzODM5ZDRiOTU0ICovXG5cbi8qIEF2YWlsYWJsZSBmdW5jdGlvbnM6XG5cbiAgICAjIEtleS9ub25jZSBnZW5lcmF0aW9uOlxuICAgIGdlbmVyYXRlQXNzeW1ldHJpY0tleXNGb3JFbmNyeXB0aW9uKCk6IFByb21pc2U8Q3J5cHRvS2V5W10+XG4gICAgZ2VuZXJhdGVBc3N5bWV0cmljS2V5c0ZvclNpZ25hdHVyZSgpOiBQcm9taXNlPENyeXB0b0tleVtdPlxuICAgIGdlbmVyYXRlU3ltZXRyaWNLZXkoKTogUHJvbWlzZTxDcnlwdG9LZXk+XG4gICAgZ2VuZXJhdGVOb25jZSgpOiBzdHJpbmdcblxuICAgICMgQXNzeW1ldHJpYyBrZXkgRW5jcnlwdGlvbi9EZWNyeXB0aW9uL1NpZ25hdHVyZS9TaWduYXR1cmUgdmVyaWZpY2F0aW9uXG4gICAgZW5jcnlwdFdpdGhQdWJsaWNLZXkocGtleTogQ3J5cHRvS2V5LCBtZXNzYWdlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz5cbiAgICBkZWNyeXB0V2l0aFByaXZhdGVLZXkoc2tleTogQ3J5cHRvS2V5LCBtZXNzYWdlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz5cbiAgICBzaWduV2l0aFByaXZhdGVLZXkocHJpdmF0ZUtleTogQ3J5cHRvS2V5LCBtZXNzYWdlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz5cbiAgICB2ZXJpZnlTaWduYXR1cmVXaXRoUHVibGljS2V5KHB1YmxpY0tleTogQ3J5cHRvS2V5LCBtZXNzYWdlSW5DbGVhcjogc3RyaW5nLCBzaWduZWRNZXNzYWdlOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+XG5cbiAgICAjIFN5bW1ldHJpYyBrZXkgRW5jcnlwdGlvbi9EZWNyeXB0aW9uXG4gICAgZW5jcnlwdFdpdGhTeW1tZXRyaWNLZXkoa2V5OiBDcnlwdG9LZXksIG1lc3NhZ2U6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nW10+XG4gICAgZGVjcnlwdFdpdGhTeW1tZXRyaWNLZXkoa2V5OiBDcnlwdG9LZXksIG1lc3NhZ2U6IHN0cmluZywgaW5pdFZlY3Rvcjogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+XG5cbiAgICAjIEltcG9ydGluZyBrZXlzIGZyb20gc3RyaW5nXG4gICAgc3RyaW5nVG9QdWJsaWNLZXlGb3JFbmNyeXB0aW9uKHBrZXlJbkJhc2U2NDogc3RyaW5nKTogUHJvbWlzZTxDcnlwdG9LZXk+XG4gICAgc3RyaW5nVG9Qcml2YXRlS2V5Rm9yRW5jcnlwdGlvbihza2V5SW5CYXNlNjQ6IHN0cmluZyk6IFByb21pc2U8Q3J5cHRvS2V5PlxuICAgIHN0cmluZ1RvUHVibGljS2V5Rm9yU2lnbmF0dXJlKHBrZXlJbkJhc2U2NDogc3RyaW5nKTogUHJvbWlzZTxDcnlwdG9LZXk+XG4gICAgc3RyaW5nVG9Qcml2YXRlS2V5Rm9yU2lnbmF0dXJlKHNrZXlJbkJhc2U2NDogc3RyaW5nKTogUHJvbWlzZTxDcnlwdG9LZXk+XG4gICAgc3RyaW5nVG9TeW1tZXRyaWNLZXkoc2tleUJhc2U2NDogc3RyaW5nKTogUHJvbWlzZTxDcnlwdG9LZXk+XG5cbiAgICAjIEV4cG9ydGluZyBrZXlzIHRvIHN0cmluZ1xuICAgIHB1YmxpY0tleVRvU3RyaW5nKGtleTogQ3J5cHRvS2V5KTogUHJvbWlzZTxzdHJpbmc+XG4gICAgcHJpdmF0ZUtleVRvU3RyaW5nKGtleTogQ3J5cHRvS2V5KTogUHJvbWlzZTxzdHJpbmc+XG4gICAgc3ltbWV0cmljS2V5VG9TdHJpbmcoa2V5OiBDcnlwdG9LZXkpOiBQcm9taXNlPHN0cmluZz5cblxuICAgICMgSGFzaGluZ1xuICAgIGhhc2godGV4dDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+XG4qL1xuXG4vLyBMaWJDcnlwdG8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuLypcbkltcG9ydHMgdGhlIGdpdmVuIHB1YmxpYyBrZXkgKGZvciBlbmNyeXB0aW9uKSBmcm9tIHRoZSBpbXBvcnQgc3BhY2UuXG5UaGUgU3VidGxlQ3J5cHRvIGltcG9zZXMgdG8gdXNlIHRoZSBcInNwa2lcIiBmb3JtYXQgZm9yIGV4cG9ydGluZyBwdWJsaWMga2V5cy5cbiovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3RyaW5nVG9QdWJsaWNLZXlGb3JFbmNyeXB0aW9uKHBrZXlCYXNlNjQ6IHN0cmluZyk6IFByb21pc2U8Q3J5cHRvS2V5PiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3Qga2V5QXJyYXlCdWZmZXI6IEFycmF5QnVmZmVyID0gYmFzZTY0U3RyaW5nVG9BcnJheUJ1ZmZlcihwa2V5QmFzZTY0KVxuICAgICAgICBjb25zdCBrZXk6IENyeXB0b0tleSA9IGF3YWl0IHdpbmRvdy5jcnlwdG8uc3VidGxlLmltcG9ydEtleShcbiAgICAgICAgICAgIFwic3BraVwiLFxuICAgICAgICAgICAga2V5QXJyYXlCdWZmZXIsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbmFtZTogXCJSU0EtT0FFUFwiLFxuICAgICAgICAgICAgICAgIGhhc2g6IFwiU0hBLTI1NlwiLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHRydWUsXG4gICAgICAgICAgICBbXCJlbmNyeXB0XCJdXG4gICAgICAgIClcbiAgICAgICAgcmV0dXJuIGtleVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBET01FeGNlcHRpb24pIHsgY29uc29sZS5sb2coXCJTdHJpbmcgZm9yIHRoZSBwdWJsaWMga2V5IChmb3IgZW5jcnlwdGlvbikgaXMgaWxsLWZvcm1lZCFcIikgfVxuICAgICAgICBlbHNlIGlmIChlIGluc3RhbmNlb2YgS2V5U3RyaW5nQ29ycnVwdGVkKSB7IGNvbnNvbGUubG9nKFwiU3RyaW5nIGZvciB0aGUgcHVibGljIGtleSAoZm9yIGVuY3J5cHRpb24pIGlzIGlsbC1mb3JtZWQhXCIpIH1cbiAgICAgICAgZWxzZSB7IGNvbnNvbGUubG9nKGUpIH1cbiAgICAgICAgdGhyb3cgZVxuICAgIH1cbn1cblxuLypcbkltcG9ydHMgdGhlIGdpdmVuIHB1YmxpYyBrZXkgKGZvciBzaWduYXR1cmUgdmVyaWZpY2F0aW9uKSBmcm9tIHRoZSBpbXBvcnQgc3BhY2UuXG5UaGUgU3VidGxlQ3J5cHRvIGltcG9zZXMgdG8gdXNlIHRoZSBcInNwa2lcIiBmb3JtYXQgZm9yIGV4cG9ydGluZyBwdWJsaWMga2V5cy5cbiovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3RyaW5nVG9QdWJsaWNLZXlGb3JTaWduYXR1cmUocGtleUJhc2U2NDogc3RyaW5nKTogUHJvbWlzZTxDcnlwdG9LZXk+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBrZXlBcnJheUJ1ZmZlcjogQXJyYXlCdWZmZXIgPSBiYXNlNjRTdHJpbmdUb0FycmF5QnVmZmVyKHBrZXlCYXNlNjQpXG4gICAgICAgIGNvbnN0IGtleTogQ3J5cHRvS2V5ID0gYXdhaXQgd2luZG93LmNyeXB0by5zdWJ0bGUuaW1wb3J0S2V5KFxuICAgICAgICAgICAgXCJzcGtpXCIsXG4gICAgICAgICAgICBrZXlBcnJheUJ1ZmZlcixcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcIlJTQVNTQS1QS0NTMS12MV81XCIsXG4gICAgICAgICAgICAgICAgaGFzaDogXCJTSEEtMjU2XCIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgdHJ1ZSxcbiAgICAgICAgICAgIFtcInZlcmlmeVwiXVxuICAgICAgICApXG4gICAgICAgIHJldHVybiBrZXlcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGlmIChlIGluc3RhbmNlb2YgRE9NRXhjZXB0aW9uKSB7IGNvbnNvbGUubG9nKFwiU3RyaW5nIGZvciB0aGUgcHVibGljIGtleSAoZm9yIHNpZ25hdHVyZSB2ZXJpZmljYXRpb24pIGlzIGlsbC1mb3JtZWQhXCIpIH1cbiAgICAgICAgZWxzZSBpZiAoZSBpbnN0YW5jZW9mIEtleVN0cmluZ0NvcnJ1cHRlZCkgeyBjb25zb2xlLmxvZyhcIlN0cmluZyBmb3IgdGhlIHB1YmxpYyBrZXkgKGZvciBzaWduYXR1cmUgdmVyaWZpY2F0aW9uKSBpcyBpbGwtZm9ybWVkIVwiKSB9XG4gICAgICAgIGVsc2UgeyBjb25zb2xlLmxvZyhlKSB9XG4gICAgICAgIHRocm93IGVcbiAgICB9XG59XG5cbi8qXG5JbXBvcnRzIHRoZSBnaXZlbiBwcml2YXRlIGtleSAoaW4gc3RyaW5nKSBhcyBhIHZhbGlkIHByaXZhdGUga2V5IChmb3IgZGVjcnlwdGlvbilcblRoZSBTdWJ0bGVDcnlwdG8gaW1wb3NlcyB0byB1c2UgdGhlIFwicGtjczhcIiA/PyBmb3JtYXQgZm9yIGltcG9ydGluZyBwdWJsaWMga2V5cy5cbiovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3RyaW5nVG9Qcml2YXRlS2V5Rm9yRW5jcnlwdGlvbihza2V5QmFzZTY0OiBzdHJpbmcpOiBQcm9taXNlPENyeXB0b0tleT4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGtleUFycmF5QnVmZmVyOiBBcnJheUJ1ZmZlciA9IGJhc2U2NFN0cmluZ1RvQXJyYXlCdWZmZXIoc2tleUJhc2U2NClcbiAgICAgICAgY29uc3Qga2V5OiBDcnlwdG9LZXkgPSBhd2FpdCB3aW5kb3cuY3J5cHRvLnN1YnRsZS5pbXBvcnRLZXkoXG4gICAgICAgICAgICBcInBrY3M4XCIsXG4gICAgICAgICAgICBrZXlBcnJheUJ1ZmZlcixcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcIlJTQS1PQUVQXCIsXG4gICAgICAgICAgICAgICAgaGFzaDogXCJTSEEtMjU2XCIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgdHJ1ZSxcbiAgICAgICAgICAgIFtcImRlY3J5cHRcIl0pXG4gICAgICAgIHJldHVybiBrZXlcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGlmIChlIGluc3RhbmNlb2YgRE9NRXhjZXB0aW9uKSB7IGNvbnNvbGUubG9nKFwiU3RyaW5nIGZvciB0aGUgcHJpdmF0ZSBrZXkgKGZvciBkZWNyeXB0aW9uKSBpcyBpbGwtZm9ybWVkIVwiKSB9XG4gICAgICAgIGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBLZXlTdHJpbmdDb3JydXB0ZWQpIHsgY29uc29sZS5sb2coXCJTdHJpbmcgZm9yIHRoZSBwcml2YXRlIGtleSAoZm9yIGRlY3J5cHRpb24pIGlzIGlsbC1mb3JtZWQhXCIpIH1cbiAgICAgICAgZWxzZSB7IGNvbnNvbGUubG9nKGUpIH1cbiAgICAgICAgdGhyb3cgZVxuICAgIH1cbn1cblxuLypcbkltcG9ydHMgdGhlIGdpdmVuIHByaXZhdGUga2V5IChpbiBzdHJpbmcpIGFzIGEgdmFsaWQgcHJpdmF0ZSBrZXkgKGZvciBzaWduYXR1cmUpXG5UaGUgU3VidGxlQ3J5cHRvIGltcG9zZXMgdG8gdXNlIHRoZSBcInBrY3M4XCIgPz8gZm9ybWF0IGZvciBpbXBvcnRpbmcgcHVibGljIGtleXMuXG4qL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHN0cmluZ1RvUHJpdmF0ZUtleUZvclNpZ25hdHVyZShza2V5QmFzZTY0OiBzdHJpbmcpOiBQcm9taXNlPENyeXB0b0tleT4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGtleUFycmF5QnVmZmVyOiBBcnJheUJ1ZmZlciA9IGJhc2U2NFN0cmluZ1RvQXJyYXlCdWZmZXIoc2tleUJhc2U2NClcbiAgICAgICAgY29uc3Qga2V5OiBDcnlwdG9LZXkgPSBhd2FpdCB3aW5kb3cuY3J5cHRvLnN1YnRsZS5pbXBvcnRLZXkoXG4gICAgICAgICAgICBcInBrY3M4XCIsXG4gICAgICAgICAgICBrZXlBcnJheUJ1ZmZlcixcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcIlJTQVNTQS1QS0NTMS12MV81XCIsXG4gICAgICAgICAgICAgICAgaGFzaDogXCJTSEEtMjU2XCIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgdHJ1ZSxcbiAgICAgICAgICAgIFtcInNpZ25cIl0pXG4gICAgICAgIHJldHVybiBrZXlcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGlmIChlIGluc3RhbmNlb2YgRE9NRXhjZXB0aW9uKSB7IGNvbnNvbGUubG9nKFwiU3RyaW5nIGZvciB0aGUgcHJpdmF0ZSBrZXkgKGZvciBzaWduYXR1cmUpIGlzIGlsbC1mb3JtZWQhXCIpIH1cbiAgICAgICAgZWxzZSBpZiAoZSBpbnN0YW5jZW9mIEtleVN0cmluZ0NvcnJ1cHRlZCkgeyBjb25zb2xlLmxvZyhcIlN0cmluZyBmb3IgdGhlIHByaXZhdGUga2V5IChmb3Igc2lnbmF0dXJlKSBpcyBpbGwtZm9ybWVkIVwiKSB9XG4gICAgICAgIGVsc2UgeyBjb25zb2xlLmxvZyhlKSB9XG4gICAgICAgIHRocm93IGVcbiAgICB9XG59XG4vKlxuRXhwb3J0cyB0aGUgZ2l2ZW4gcHVibGljIGtleSBpbnRvIGEgdmFsaWQgc3RyaW5nLlxuVGhlIFN1YnRsZUNyeXB0byBpbXBvc2VzIHRvIHVzZSB0aGUgXCJzcGtpXCIgZm9ybWF0IGZvciBleHBvcnRpbmcgcHVibGljIGtleXMuXG4qL1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHVibGljS2V5VG9TdHJpbmcoa2V5OiBDcnlwdG9LZXkpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IGV4cG9ydGVkS2V5OiBBcnJheUJ1ZmZlciA9IGF3YWl0IHdpbmRvdy5jcnlwdG8uc3VidGxlLmV4cG9ydEtleShcInNwa2lcIiwga2V5KVxuICAgIHJldHVybiBhcnJheUJ1ZmZlclRvQmFzZTY0U3RyaW5nKGV4cG9ydGVkS2V5KVxufVxuXG4vKlxuRXhwb3J0cyB0aGUgZ2l2ZW4gcHVibGljIGtleSBpbnRvIGEgdmFsaWQgc3RyaW5nLlxuVGhlIFN1YnRsZUNyeXB0byBpbXBvc2VzIHRvIHVzZSB0aGUgXCJzcGtpXCIgZm9ybWF0IGZvciBleHBvcnRpbmcgcHVibGljIGtleXMuXG4qL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHByaXZhdGVLZXlUb1N0cmluZyhrZXk6IENyeXB0b0tleSk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgZXhwb3J0ZWRLZXk6IEFycmF5QnVmZmVyID0gYXdhaXQgd2luZG93LmNyeXB0by5zdWJ0bGUuZXhwb3J0S2V5KFwicGtjczhcIiwga2V5KVxuICAgIHJldHVybiBhcnJheUJ1ZmZlclRvQmFzZTY0U3RyaW5nKGV4cG9ydGVkS2V5KVxufVxuXG4vKiBHZW5lcmF0ZXMgYSBwYWlyIG9mIHB1YmxpYyBhbmQgcHJpdmF0ZSBSU0Ega2V5cyBmb3IgZW5jcnlwdGlvbi9kZWNyeXB0aW9uICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVBc3N5bWV0cmljS2V5c0ZvckVuY3J5cHRpb24oKTogUHJvbWlzZTxDcnlwdG9LZXlbXT4ge1xuICAgIGNvbnN0IGtleXBhaXI6IENyeXB0b0tleVBhaXIgPSBhd2FpdCB3aW5kb3cuY3J5cHRvLnN1YnRsZS5nZW5lcmF0ZUtleShcbiAgICAgICAge1xuICAgICAgICAgICAgbmFtZTogXCJSU0EtT0FFUFwiLFxuICAgICAgICAgICAgbW9kdWx1c0xlbmd0aDogMjA0OCxcbiAgICAgICAgICAgIHB1YmxpY0V4cG9uZW50OiBuZXcgVWludDhBcnJheShbMSwgMCwgMV0pLFxuICAgICAgICAgICAgaGFzaDogXCJTSEEtMjU2XCIsXG4gICAgICAgIH0sXG4gICAgICAgIHRydWUsXG4gICAgICAgIFtcImVuY3J5cHRcIiwgXCJkZWNyeXB0XCJdXG4gICAgKVxuICAgIHJldHVybiBba2V5cGFpci5wdWJsaWNLZXksIGtleXBhaXIucHJpdmF0ZUtleV1cbn1cblxuLyogR2VuZXJhdGVzIGEgcGFpciBvZiBwdWJsaWMgYW5kIHByaXZhdGUgUlNBIGtleXMgZm9yIHNpZ25pbmcvdmVyaWZ5aW5nICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVBc3N5bWV0cmljS2V5c0ZvclNpZ25hdHVyZSgpOiBQcm9taXNlPENyeXB0b0tleVtdPiB7XG4gICAgY29uc3Qga2V5cGFpcjogQ3J5cHRvS2V5UGFpciA9IGF3YWl0IHdpbmRvdy5jcnlwdG8uc3VidGxlLmdlbmVyYXRlS2V5KFxuICAgICAgICB7XG4gICAgICAgICAgICBuYW1lOiBcIlJTQVNTQS1QS0NTMS12MV81XCIsXG4gICAgICAgICAgICBtb2R1bHVzTGVuZ3RoOiAyMDQ4LFxuICAgICAgICAgICAgcHVibGljRXhwb25lbnQ6IG5ldyBVaW50OEFycmF5KFsxLCAwLCAxXSksXG4gICAgICAgICAgICBoYXNoOiBcIlNIQS0yNTZcIixcbiAgICAgICAgfSxcbiAgICAgICAgdHJ1ZSxcbiAgICAgICAgW1wic2lnblwiLCBcInZlcmlmeVwiXVxuICAgIClcbiAgICByZXR1cm4gW2tleXBhaXIucHVibGljS2V5LCBrZXlwYWlyLnByaXZhdGVLZXldXG59XG5cbi8qIEdlbmVyYXRlcyBhIHJhbmRvbSBub25jZSAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdlbmVyYXRlTm9uY2UoKTogc3RyaW5nIHtcbiAgICBjb25zdCBub25jZUFycmF5ID0gbmV3IFVpbnQzMkFycmF5KDEpXG4gICAgc2VsZi5jcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5vbmNlQXJyYXkpXG4gICAgcmV0dXJuIG5vbmNlQXJyYXlbMF0udG9TdHJpbmcoKVxufVxuXG4vKiBFbmNyeXB0cyBhIG1lc3NhZ2Ugd2l0aCBhIHB1YmxpYyBrZXkgKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbmNyeXB0V2l0aFB1YmxpY0tleShwdWJsaWNLZXk6IENyeXB0b0tleSwgbWVzc2FnZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBtZXNzYWdlVG9BcnJheUJ1ZmZlciA9IHRleHRUb0FycmF5QnVmZmVyKG1lc3NhZ2UpXG4gICAgICAgIGNvbnN0IGN5cGhlcmVkTWVzc2FnZUFCOiBBcnJheUJ1ZmZlciA9IGF3YWl0IHdpbmRvdy5jcnlwdG8uc3VidGxlLmVuY3J5cHQoXG4gICAgICAgICAgICB7IG5hbWU6IFwiUlNBLU9BRVBcIiB9LFxuICAgICAgICAgICAgcHVibGljS2V5LFxuICAgICAgICAgICAgbWVzc2FnZVRvQXJyYXlCdWZmZXJcbiAgICAgICAgKVxuICAgICAgICByZXR1cm4gYXJyYXlCdWZmZXJUb0Jhc2U2NFN0cmluZyhjeXBoZXJlZE1lc3NhZ2VBQilcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGlmIChlIGluc3RhbmNlb2YgRE9NRXhjZXB0aW9uKSB7IGNvbnNvbGUubG9nKGUpOyBjb25zb2xlLmxvZyhcIkVuY3J5cHRpb24gZmFpbGVkIVwiKSB9XG4gICAgICAgIGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBLZXlTdHJpbmdDb3JydXB0ZWQpIHsgY29uc29sZS5sb2coXCJQdWJsaWMga2V5IG9yIG1lc3NhZ2UgdG8gZW5jcnlwdCBpcyBpbGwtZm9ybWVkXCIpIH1cbiAgICAgICAgZWxzZSB7IGNvbnNvbGUubG9nKGUpIH1cbiAgICAgICAgdGhyb3cgZVxuICAgIH1cbn1cblxuLyogU2lnbiBhIG1lc3NhZ2Ugd2l0aCBhIHByaXZhdGUga2V5ICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2lnbldpdGhQcml2YXRlS2V5KHByaXZhdGVLZXk6IENyeXB0b0tleSwgbWVzc2FnZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBtZXNzYWdlVG9BcnJheUJ1ZmZlciA9IHRleHRUb0FycmF5QnVmZmVyKG1lc3NhZ2UpXG4gICAgICAgIGNvbnN0IHNpZ25lZE1lc3NhZ2VBQjogQXJyYXlCdWZmZXIgPSBhd2FpdCB3aW5kb3cuY3J5cHRvLnN1YnRsZS5zaWduKFxuICAgICAgICAgICAgXCJSU0FTU0EtUEtDUzEtdjFfNVwiLFxuICAgICAgICAgICAgcHJpdmF0ZUtleSxcbiAgICAgICAgICAgIG1lc3NhZ2VUb0FycmF5QnVmZmVyXG4gICAgICAgIClcbiAgICAgICAgcmV0dXJuIGFycmF5QnVmZmVyVG9CYXNlNjRTdHJpbmcoc2lnbmVkTWVzc2FnZUFCKVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBET01FeGNlcHRpb24pIHsgY29uc29sZS5sb2coZSk7IGNvbnNvbGUubG9nKFwiU2lnbmF0dXJlIGZhaWxlZCFcIikgfVxuICAgICAgICBlbHNlIGlmIChlIGluc3RhbmNlb2YgS2V5U3RyaW5nQ29ycnVwdGVkKSB7IGNvbnNvbGUubG9nKFwiUHJpdmF0ZSBrZXkgb3IgbWVzc2FnZSB0byBzaWduIGlzIGlsbC1mb3JtZWRcIikgfVxuICAgICAgICBlbHNlIHsgY29uc29sZS5sb2coZSkgfVxuICAgICAgICB0aHJvdyBlXG4gICAgfVxufVxuXG5cbi8qIERlY3J5cHRzIGEgbWVzc2FnZSB3aXRoIGEgcHJpdmF0ZSBrZXkgKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWNyeXB0V2l0aFByaXZhdGVLZXkocHJpdmF0ZUtleTogQ3J5cHRvS2V5LCBtZXNzYWdlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGRlY3J5dHBlZE1lc3NhZ2VBQjogQXJyYXlCdWZmZXIgPSBhd2FpdFxuICAgICAgICAgICAgd2luZG93LmNyeXB0by5zdWJ0bGUuZGVjcnlwdChcbiAgICAgICAgICAgICAgICB7IG5hbWU6IFwiUlNBLU9BRVBcIiB9LFxuICAgICAgICAgICAgICAgIHByaXZhdGVLZXksXG4gICAgICAgICAgICAgICAgYmFzZTY0U3RyaW5nVG9BcnJheUJ1ZmZlcihtZXNzYWdlKVxuICAgICAgICAgICAgKVxuICAgICAgICByZXR1cm4gYXJyYXlCdWZmZXJUb1RleHQoZGVjcnl0cGVkTWVzc2FnZUFCKVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBET01FeGNlcHRpb24pIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiSW52YWxpZCBrZXksIG1lc3NhZ2Ugb3IgYWxnb3JpdGhtIGZvciBkZWNyeXB0aW9uXCIpXG4gICAgICAgIH0gZWxzZSBpZiAoZSBpbnN0YW5jZW9mIEtleVN0cmluZ0NvcnJ1cHRlZCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJQcml2YXRlIGtleSBvciBtZXNzYWdlIHRvIGRlY3J5cHQgaXMgaWxsLWZvcm1lZFwiKVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgY29uc29sZS5sb2coXCJEZWNyeXB0aW9uIGZhaWxlZFwiKVxuICAgICAgICB0aHJvdyBlXG4gICAgfVxufVxuXG5cbi8qIFZlcmlmaWNhdGlvbiBvZiBhIHNpZ25hdHVyZSBvbiBhIG1lc3NhZ2Ugd2l0aCBhIHB1YmxpYyBrZXkgKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB2ZXJpZnlTaWduYXR1cmVXaXRoUHVibGljS2V5KHB1YmxpY0tleTogQ3J5cHRvS2V5LCBtZXNzYWdlSW5DbGVhcjogc3RyaW5nLCBzaWduZWRNZXNzYWdlOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBzaWduZWRUb0FycmF5QnVmZmVyID0gYmFzZTY0U3RyaW5nVG9BcnJheUJ1ZmZlcihzaWduZWRNZXNzYWdlKVxuICAgICAgICBjb25zdCBtZXNzYWdlSW5DbGVhclRvQXJyYXlCdWZmZXIgPSB0ZXh0VG9BcnJheUJ1ZmZlcihtZXNzYWdlSW5DbGVhcilcbiAgICAgICAgY29uc3QgdmVyaWZpZWQ6IGJvb2xlYW4gPSBhd2FpdFxuICAgICAgICAgICAgd2luZG93LmNyeXB0by5zdWJ0bGUudmVyaWZ5KFxuICAgICAgICAgICAgICAgIFwiUlNBU1NBLVBLQ1MxLXYxXzVcIixcbiAgICAgICAgICAgICAgICBwdWJsaWNLZXksXG4gICAgICAgICAgICAgICAgc2lnbmVkVG9BcnJheUJ1ZmZlcixcbiAgICAgICAgICAgICAgICBtZXNzYWdlSW5DbGVhclRvQXJyYXlCdWZmZXIpXG4gICAgICAgIHJldHVybiB2ZXJpZmllZFxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBET01FeGNlcHRpb24pIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiSW52YWxpZCBrZXksIG1lc3NhZ2Ugb3IgYWxnb3JpdGhtIGZvciBzaWduYXR1cmUgdmVyaWZpY2F0aW9uXCIpXG4gICAgICAgIH0gZWxzZSBpZiAoZSBpbnN0YW5jZW9mIEtleVN0cmluZ0NvcnJ1cHRlZCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJQdWJsaWMga2V5IG9yIHNpZ25lZCBtZXNzYWdlIHRvIHZlcmlmeSBpcyBpbGwtZm9ybWVkXCIpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBjb25zb2xlLmxvZyhcIkRlY3J5cHRpb24gZmFpbGVkXCIpXG4gICAgICAgIHRocm93IGVcbiAgICB9XG59XG5cblxuLyogR2VuZXJhdGVzIGEgc3ltbWV0cmljIEFFUy1HQ00ga2V5ICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVTeW1ldHJpY0tleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xuICAgIGNvbnN0IGtleTogQ3J5cHRvS2V5ID0gYXdhaXQgd2luZG93LmNyeXB0by5zdWJ0bGUuZ2VuZXJhdGVLZXkoXG4gICAgICAgIHtcbiAgICAgICAgICAgIG5hbWU6IFwiQUVTLUdDTVwiLFxuICAgICAgICAgICAgbGVuZ3RoOiAyNTYsXG4gICAgICAgIH0sXG4gICAgICAgIHRydWUsXG4gICAgICAgIFtcImVuY3J5cHRcIiwgXCJkZWNyeXB0XCJdXG4gICAgKVxuICAgIHJldHVybiBrZXlcbn1cblxuLyogYSBzeW1tZXRyaWMgQUVTIGtleSBpbnRvIGEgc3RyaW5nICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3ltbWV0cmljS2V5VG9TdHJpbmcoa2V5OiBDcnlwdG9LZXkpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IGV4cG9ydGVkS2V5OiBBcnJheUJ1ZmZlciA9IGF3YWl0IHdpbmRvdy5jcnlwdG8uc3VidGxlLmV4cG9ydEtleShcInJhd1wiLCBrZXkpXG4gICAgcmV0dXJuIGFycmF5QnVmZmVyVG9CYXNlNjRTdHJpbmcoZXhwb3J0ZWRLZXkpXG59XG5cbi8qIEltcG9ydHMgdGhlIGdpdmVuIGtleSAoaW4gc3RyaW5nKSBhcyBhIHZhbGlkIEFFUyBrZXkgKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzdHJpbmdUb1N5bW1ldHJpY0tleShza2V5QmFzZTY0OiBzdHJpbmcpOiBQcm9taXNlPENyeXB0b0tleT4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGtleUFycmF5QnVmZmVyOiBBcnJheUJ1ZmZlciA9IGJhc2U2NFN0cmluZ1RvQXJyYXlCdWZmZXIoc2tleUJhc2U2NClcbiAgICAgICAgY29uc3Qga2V5OiBDcnlwdG9LZXkgPSBhd2FpdCB3aW5kb3cuY3J5cHRvLnN1YnRsZS5pbXBvcnRLZXkoXG4gICAgICAgICAgICBcInJhd1wiLFxuICAgICAgICAgICAga2V5QXJyYXlCdWZmZXIsXG4gICAgICAgICAgICBcIkFFUy1HQ01cIixcbiAgICAgICAgICAgIHRydWUsXG4gICAgICAgICAgICBbXCJlbmNyeXB0XCIsIFwiZGVjcnlwdFwiXSlcbiAgICAgICAgcmV0dXJuIGtleVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBET01FeGNlcHRpb24pIHsgY29uc29sZS5sb2coXCJTdHJpbmcgZm9yIHRoZSBzeW1tZXRyaWMga2V5IGlzIGlsbC1mb3JtZWQhXCIpIH1cbiAgICAgICAgZWxzZSBpZiAoZSBpbnN0YW5jZW9mIEtleVN0cmluZ0NvcnJ1cHRlZCkgeyBjb25zb2xlLmxvZyhcIlN0cmluZyBmb3IgdGhlIHN5bW1ldHJpYyBrZXkgaXMgaWxsLWZvcm1lZCFcIikgfVxuICAgICAgICBlbHNlIHsgY29uc29sZS5sb2coZSkgfVxuICAgICAgICB0aHJvdyBlXG4gICAgfVxufVxuXG5cbi8vIFdoZW4gY3lwaGVyaW5nIGEgbWVzc2FnZSB3aXRoIGEga2V5IGluIEFFUywgd2Ugb2J0YWluIGEgY3lwaGVyZWQgbWVzc2FnZSBhbmQgYW4gXCJpbml0aWFsaXNhdGlvbiB2ZWN0b3JcIi5cbi8vIEluIHRoaXMgaW1wbGVtZW50YXRpb24sIHRoZSBvdXRwdXQgaXMgYSB0d28gZWxlbWVudHMgYXJyYXkgdCBzdWNoIHRoYXQgdFswXSBpcyB0aGUgY3lwaGVyZWQgbWVzc2FnZVxuLy8gYW5kIHRbMV0gaXMgdGhlIGluaXRpYWxpc2F0aW9uIHZlY3Rvci4gVG8gc2ltcGxpZnksIHRoZSBpbml0aWFsaXNhdGlvbiB2ZWN0b3IgaXMgcmVwcmVzZW50ZWQgYnkgYSBzdHJpbmcuXG4vLyBUaGUgaW5pdGlhbGlzYXRpb24gdmVjdG9yZSBpcyB1c2VkIGZvciBwcm90ZWN0aW5nIHRoZSBlbmNyeXB0aW9uLCBpLmUsIDIgZW5jcnlwdGlvbnMgb2YgdGhlIHNhbWUgbWVzc2FnZSBcbi8vIHdpdGggdGhlIHNhbWUga2V5IHdpbGwgbmV2ZXIgcmVzdWx0IGludG8gdGhlIHNhbWUgZW5jcnlwdGVkIG1lc3NhZ2UuXG4vLyBcbi8vIE5vdGUgdGhhdCBmb3IgZGVjeXBoZXJpbmcsIHRoZSAqKnNhbWUqKiBpbml0aWFsaXNhdGlvbiB2ZWN0b3Igd2lsbCBiZSBuZWVkZWQuXG4vLyBUaGlzIHZlY3RvciBjYW4gc2FmZWx5IGJlIHRyYW5zZmVycmVkIGluIGNsZWFyIHdpdGggdGhlIGVuY3J5cHRlZCBtZXNzYWdlLlxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5jcnlwdFdpdGhTeW1tZXRyaWNLZXkoa2V5OiBDcnlwdG9LZXksIG1lc3NhZ2U6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nW10+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBtZXNzYWdlVG9BcnJheUJ1ZmZlciA9IHRleHRUb0FycmF5QnVmZmVyKG1lc3NhZ2UpXG4gICAgICAgIGNvbnN0IGl2ID0gd2luZG93LmNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMTIpKTtcbiAgICAgICAgY29uc3QgaXZUZXh0ID0gYXJyYXlCdWZmZXJUb0Jhc2U2NFN0cmluZyhpdilcbiAgICAgICAgY29uc3QgY3lwaGVyZWRNZXNzYWdlQUI6IEFycmF5QnVmZmVyID0gYXdhaXQgd2luZG93LmNyeXB0by5zdWJ0bGUuZW5jcnlwdChcbiAgICAgICAgICAgIHsgbmFtZTogXCJBRVMtR0NNXCIsIGl2IH0sXG4gICAgICAgICAgICBrZXksXG4gICAgICAgICAgICBtZXNzYWdlVG9BcnJheUJ1ZmZlclxuICAgICAgICApXG4gICAgICAgIHJldHVybiBbYXJyYXlCdWZmZXJUb0Jhc2U2NFN0cmluZyhjeXBoZXJlZE1lc3NhZ2VBQiksIGl2VGV4dF1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGlmIChlIGluc3RhbmNlb2YgRE9NRXhjZXB0aW9uKSB7IGNvbnNvbGUubG9nKGUpOyBjb25zb2xlLmxvZyhcIkVuY3J5cHRpb24gZmFpbGVkIVwiKSB9XG4gICAgICAgIGVsc2UgaWYgKGUgaW5zdGFuY2VvZiBLZXlTdHJpbmdDb3JydXB0ZWQpIHsgY29uc29sZS5sb2coXCJTeW1tZXRyaWMga2V5IG9yIG1lc3NhZ2UgdG8gZW5jcnlwdCBpcyBpbGwtZm9ybWVkXCIpIH1cbiAgICAgICAgZWxzZSB7IGNvbnNvbGUubG9nKGUpIH1cbiAgICAgICAgdGhyb3cgZVxuICAgIH1cbn1cblxuLy8gRm9yIGRlY3lwaGVyaW5nLCB3ZSBuZWVkIHRoZSBrZXksIHRoZSBjeXBoZXJlZCBtZXNzYWdlIGFuZCB0aGUgaW5pdGlhbGl6YXRpb24gdmVjdG9yLiBTZWUgYWJvdmUgdGhlIFxuLy8gY29tbWVudHMgZm9yIHRoZSBlbmNyeXB0V2l0aFN5bW1ldHJpY0tleSBmdW5jdGlvblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlY3J5cHRXaXRoU3ltbWV0cmljS2V5KGtleTogQ3J5cHRvS2V5LCBtZXNzYWdlOiBzdHJpbmcsIGluaXRWZWN0b3I6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgZGVjb2RlZEluaXRWZWN0b3I6IEFycmF5QnVmZmVyID0gYmFzZTY0U3RyaW5nVG9BcnJheUJ1ZmZlcihpbml0VmVjdG9yKVxuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGRlY3J5dHBlZE1lc3NhZ2VBQjogQXJyYXlCdWZmZXIgPSBhd2FpdFxuICAgICAgICAgICAgd2luZG93LmNyeXB0by5zdWJ0bGUuZGVjcnlwdChcbiAgICAgICAgICAgICAgICB7IG5hbWU6IFwiQUVTLUdDTVwiLCBpdjogZGVjb2RlZEluaXRWZWN0b3IgfSxcbiAgICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgICAgYmFzZTY0U3RyaW5nVG9BcnJheUJ1ZmZlcihtZXNzYWdlKVxuICAgICAgICAgICAgKVxuICAgICAgICByZXR1cm4gYXJyYXlCdWZmZXJUb1RleHQoZGVjcnl0cGVkTWVzc2FnZUFCKVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBET01FeGNlcHRpb24pIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiSW52YWxpZCBrZXksIG1lc3NhZ2Ugb3IgYWxnb3JpdGhtIGZvciBkZWNyeXB0aW9uXCIpXG4gICAgICAgIH0gZWxzZSBpZiAoZSBpbnN0YW5jZW9mIEtleVN0cmluZ0NvcnJ1cHRlZCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJTeW1tZXRyaWMga2V5IG9yIG1lc3NhZ2UgdG8gZGVjcnlwdCBpcyBpbGwtZm9ybWVkXCIpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBjb25zb2xlLmxvZyhcIkRlY3J5cHRpb24gZmFpbGVkXCIpXG4gICAgICAgIHRocm93IGVcbiAgICB9XG59XG5cbi8vIFNIQS0yNTYgSGFzaCBmcm9tIGEgdGV4dFxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhhc2godGV4dDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCB0ZXh0MmFycmF5QnVmID0gdGV4dFRvQXJyYXlCdWZmZXIodGV4dClcbiAgICBjb25zdCBoYXNoZWRBcnJheSA9IGF3YWl0IHdpbmRvdy5jcnlwdG8uc3VidGxlLmRpZ2VzdChcIlNIQS0yNTZcIiwgdGV4dDJhcnJheUJ1ZilcbiAgICByZXR1cm4gYXJyYXlCdWZmZXJUb0Jhc2U2NFN0cmluZyhoYXNoZWRBcnJheSlcbn1cblxuY2xhc3MgS2V5U3RyaW5nQ29ycnVwdGVkIGV4dGVuZHMgRXJyb3IgeyB9XG5cbi8vIEFycmF5QnVmZmVyIHRvIGEgQmFzZTY0IHN0cmluZ1xuZnVuY3Rpb24gYXJyYXlCdWZmZXJUb0Jhc2U2NFN0cmluZyhhcnJheUJ1ZmZlcjogQXJyYXlCdWZmZXIpOiBzdHJpbmcge1xuICAgIHZhciBieXRlQXJyYXkgPSBuZXcgVWludDhBcnJheShhcnJheUJ1ZmZlcilcbiAgICB2YXIgYnl0ZVN0cmluZyA9ICcnXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBieXRlQXJyYXkuYnl0ZUxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGJ5dGVTdHJpbmcgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShieXRlQXJyYXlbaV0pXG4gICAgfVxuICAgIHJldHVybiBidG9hKGJ5dGVTdHJpbmcpXG59XG5cbi8vIEJhc2U2NCBzdHJpbmcgdG8gYW4gYXJyYXlCdWZmZXJcbmZ1bmN0aW9uIGJhc2U2NFN0cmluZ1RvQXJyYXlCdWZmZXIoYjY0c3RyOiBzdHJpbmcpOiBBcnJheUJ1ZmZlciB7XG4gICAgdHJ5IHtcbiAgICAgICAgdmFyIGJ5dGVTdHIgPSBhdG9iKGI2NHN0cilcbiAgICAgICAgdmFyIGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoYnl0ZVN0ci5sZW5ndGgpXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYnl0ZVN0ci5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgYnl0ZXNbaV0gPSBieXRlU3RyLmNoYXJDb2RlQXQoaSlcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYnl0ZXMuYnVmZmVyXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmxvZyhgU3RyaW5nIHN0YXJ0aW5nIGJ5ICcke2I2NHN0ci5zdWJzdHJpbmcoMCwgMTApfScgY2Fubm90IGJlIGNvbnZlcnRlZCB0byBhIHZhbGlkIGtleSBvciBtZXNzYWdlYClcbiAgICAgICAgdGhyb3cgbmV3IEtleVN0cmluZ0NvcnJ1cHRlZFxuICAgIH1cbn1cblxuLy8gU3RyaW5nIHRvIGFycmF5IGJ1ZmZlclxuZnVuY3Rpb24gdGV4dFRvQXJyYXlCdWZmZXIoc3RyOiBzdHJpbmcpOiBBcnJheUJ1ZmZlciB7XG4gICAgdmFyIGJ1ZiA9IGVuY29kZVVSSUNvbXBvbmVudChzdHIpIC8vIDIgYnl0ZXMgZm9yIGVhY2ggY2hhclxuICAgIHZhciBidWZWaWV3ID0gbmV3IFVpbnQ4QXJyYXkoYnVmLmxlbmd0aClcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGJ1Zi5sZW5ndGg7IGkrKykge1xuICAgICAgICBidWZWaWV3W2ldID0gYnVmLmNoYXJDb2RlQXQoaSlcbiAgICB9XG4gICAgcmV0dXJuIGJ1ZlZpZXdcbn1cblxuLy8gQXJyYXkgYnVmZmVycyB0byBzdHJpbmdcbmZ1bmN0aW9uIGFycmF5QnVmZmVyVG9UZXh0KGFycmF5QnVmZmVyOiBBcnJheUJ1ZmZlcik6IHN0cmluZyB7XG4gICAgdmFyIGJ5dGVBcnJheSA9IG5ldyBVaW50OEFycmF5KGFycmF5QnVmZmVyKVxuICAgIHZhciBzdHIgPSAnJ1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYnl0ZUFycmF5LmJ5dGVMZW5ndGg7IGkrKykge1xuICAgICAgICBzdHIgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShieXRlQXJyYXlbaV0pXG4gICAgfVxuICAgIHJldHVybiBkZWNvZGVVUklDb21wb25lbnQoc3RyKVxufVxuXG4iLCAiLy8gQWxsIG1lc3NhZ2UgdHlwZXMgYmV0d2VlbiB0aGUgYXBwbGljYXRpb24gYW5kIHRoZSBzZXJ2ZXJcbi8vIE1lc3NhZ2UgZm9yIHVzZXIgbmFtZVxuZXhwb3J0IGNsYXNzIENhc1VzZXJOYW1lIHtcbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgdXNlcm5hbWU6IHN0cmluZykgeyB9XG59XG5cblxuLy8gTWVzc2FnZSBmb3IgcmVxdWlyaW5nIGhpc3RvcnlcbmV4cG9ydCBjbGFzcyBIaXN0b3J5UmVxdWVzdCB7XG4gICAgY29uc3RydWN0b3IocHVibGljIGFnZW50TmFtZTogc3RyaW5nLCBwdWJsaWMgaW5kZXg6IG51bWJlcikgeyB9XG59XG5cbi8vIFJlc3VsdCBvZiBoaXN0b3J5IHJlcXVlc3RcbmV4cG9ydCBjbGFzcyBIaXN0b3J5QW5zd2VyIHtcbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgc3VjY2VzczogYm9vbGVhbixcbiAgICAgICAgcHVibGljIGZhaWx1cmVNZXNzYWdlOiBzdHJpbmcsXG4gICAgICAgIHB1YmxpYyBpbmRleDogbnVtYmVyLFxuICAgICAgICBwdWJsaWMgYWxsTWVzc2FnZXM6IEV4dE1lc3NhZ2VbXSkgeyB9XG59XG5cbi8vIEZpbHRlcmluZyBvZiBtZXNzYWdlc1xuZXhwb3J0IGNsYXNzIEZpbHRlclJlcXVlc3Qge1xuICAgIGNvbnN0cnVjdG9yKHB1YmxpYyBmcm9tOiBzdHJpbmcsIHB1YmxpYyB0bzogc3RyaW5nLCBwdWJsaWMgaW5kZXhtaW46IHN0cmluZykgeyB9XG59XG5cbmV4cG9ydCBjbGFzcyBGaWx0ZXJlZE1lc3NhZ2Uge1xuICAgIGNvbnN0cnVjdG9yKHB1YmxpYyBtZXNzYWdlOiBFeHRNZXNzYWdlLFxuICAgICAgICBwdWJsaWMgaW5kZXg6IG51bWJlcixcbiAgICAgICAgcHVibGljIGRlbGV0ZWQ6IGJvb2xlYW4sXG4gICAgICAgIHB1YmxpYyBkZWxldGVyOiBzdHJpbmcpIHsgfVxufVxuXG4vLyBSZXN1bHQgb2YgZmlsdGVyaW5nIHJlcXVlc3RcbmV4cG9ydCBjbGFzcyBGaWx0ZXJpbmdBbnN3ZXIge1xuICAgIGNvbnN0cnVjdG9yKHB1YmxpYyBzdWNjZXNzOiBib29sZWFuLFxuICAgICAgICBwdWJsaWMgZmFpbHVyZU1lc3NhZ2U6IHN0cmluZyxcbiAgICAgICAgcHVibGljIGFsbE1lc3NhZ2VzOiBGaWx0ZXJlZE1lc3NhZ2VbXSkgeyB9XG59XG5cbi8vIFNlbmRpbmcgYSBtZXNzYWdlIFJlc3VsdCBmb3JtYXRcbmV4cG9ydCBjbGFzcyBTZW5kUmVzdWx0IHtcbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgc3VjY2VzczogYm9vbGVhbiwgcHVibGljIGVycm9yTWVzc2FnZTogc3RyaW5nKSB7IH1cbn1cblxuLy8gU2VuZGluZyBtZXNzYWdlc1xuLy8gVGhlIG1lc3NhZ2UgZm9ybWF0XG5leHBvcnQgY2xhc3MgRXh0TWVzc2FnZSB7XG4gICAgY29uc3RydWN0b3IocHVibGljIHNlbmRlcjogc3RyaW5nLCBwdWJsaWMgcmVjZWl2ZXI6IHN0cmluZywgcHVibGljIGNvbnRlbnQ6IHN0cmluZykgeyB9XG59XG5cbmV4cG9ydCBjbGFzcyBEZWxldGluZ1JlcXVlc3Qge1xuICAgIGNvbnN0cnVjdG9yKFxuICAgICAgICBwdWJsaWMgaW5kZXhUb0RlbGV0ZTogc3RyaW5nKSB7IH1cbn1cblxuZXhwb3J0IGNsYXNzIERlbGV0aW5nQW5zd2VyIHtcbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgc3VjY2VzczogYm9vbGVhbixcbiAgICAgICAgbWVzc2FnZTogc3RyaW5nKSB7IH1cbn1cblxuLy8gUmVxdWVzdGluZyBrZXlzXG5leHBvcnQgY2xhc3MgS2V5UmVxdWVzdCB7XG4gICAgY29uc3RydWN0b3IocHVibGljIG93bmVyT2ZUaGVLZXk6IHN0cmluZywgcHVibGljIHB1YmxpY0tleTogYm9vbGVhbiwgcHVibGljIGVuY3J5cHRpb246IGJvb2xlYW4pIHsgfVxufVxuXG5leHBvcnQgY2xhc3MgS2V5UmVzdWx0IHtcbiAgICBjb25zdHJ1Y3RvcihwdWJsaWMgc3VjY2VzczogYm9vbGVhbiwgcHVibGljIGtleTogc3RyaW5nLCBwdWJsaWMgZXJyb3JNZXNzYWdlOiBzdHJpbmcpIHsgfVxufSIsICIvLyBWZXJzaW9uIGFjdHVlbGxlIGR1IHByb3RvY29sZTpcbi8vIEEgLT4gQiA6IHtcImhleVwifXBrQlxuLy8gQiAtPiBBIDogeyBOYiB9cGtBXG4vLyBBIC0+IEIgOiB7IHNlY3JldCwgTmIsIE5hIH1wa0Jcbi8vIEIgLT4gQSA6IHsgTmEgfXBrQVxuXG5cbmltcG9ydCB7XG4gICAgZW5jcnlwdFdpdGhQdWJsaWNLZXksIGRlY3J5cHRXaXRoUHJpdmF0ZUtleSwgc3RyaW5nVG9Qcml2YXRlS2V5Rm9yRW5jcnlwdGlvbiwgc3RyaW5nVG9QdWJsaWNLZXlGb3JFbmNyeXB0aW9uLFxuICAgIHN0cmluZ1RvUHJpdmF0ZUtleUZvclNpZ25hdHVyZSxcbiAgICBzdHJpbmdUb1B1YmxpY0tleUZvclNpZ25hdHVyZSwgcHJpdmF0ZUtleVRvU3RyaW5nLCBoYXNoLFxuICAgIGdlbmVyYXRlTm9uY2Vcbn0gZnJvbSAnLi9saWJDcnlwdG8nICAgICAgICAvL2xlcyBmb25jdGlvbnMgcG91ciBjaGlmZnJlci9kXHUwMEU5Y2hpZmZyZXJcblxuaW1wb3J0IHtcbiAgICBIaXN0b3J5QW5zd2VyLCBIaXN0b3J5UmVxdWVzdCwgS2V5UmVxdWVzdCwgS2V5UmVzdWx0LCBDYXNVc2VyTmFtZSwgRXh0TWVzc2FnZSwgU2VuZFJlc3VsdCxcblxufSBmcm9tICcuL3NlcnZlck1lc3NhZ2VzJ1xuXG4vLyBUbyBkZXRlY3QgaWYgd2UgY2FuIHVzZSB3aW5kb3cuY3J5cHRvLnN1YnRsZVxuaWYgKCF3aW5kb3cuaXNTZWN1cmVDb250ZXh0KSBhbGVydChcIk5vdCBzZWN1cmUgY29udGV4dCFcIilcblxuLy9JbmRleCBvZiB0aGUgbGFzdCByZWFkIG1lc3NhZ2VcbmxldCBsYXN0SW5kZXhJbkhpc3RvcnkgPSAwXG5cbmNvbnN0IHVzZXJCdXR0b25MYWJlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidXNlci1uYW1lXCIpIGFzIEhUTUxMYWJlbEVsZW1lbnRcbmNvbnN0IHNlbmRCdXR0b24gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInNlbmQtYnV0dG9uXCIpIGFzIEhUTUxCdXR0b25FbGVtZW50XG5jb25zdCByZWNlaXZlciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicmVjZWl2ZXJcIikgYXMgSFRNTElucHV0RWxlbWVudFxuY29uc3QgbWVzc2FnZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibWVzc2FnZVwiKSBhcyBIVE1MSW5wdXRFbGVtZW50XG5jb25zdCByZWNlaXZlZF9tZXNzYWdlcyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZXhjaGFuZ2VkLW1lc3NhZ2VzXCIpIGFzIEhUTUxMYWJlbEVsZW1lbnRcblxubGV0IHJlY2VpdmVOb3VuY2UgOiBib29sZWFuID0gZmFsc2VcbmxldCBub3VjZUdsb2JhbCA6IHN0cmluZyA9IFwiXCJcbmxldCBjdXJyZW50Tm91Y2UgOiBzdHJpbmcgPSBcIlwiXG5sZXQgY29uZmlybWF0aW9uTm91Y2UgOiBzdHJpbmcgPSBcIlwiXG5cbmZ1bmN0aW9uIGNsZWFyaW5nTWVzc2FnZXMoKSB7XG4gICAgcmVjZWl2ZWRfbWVzc2FnZXMudGV4dENvbnRlbnQgPSBcIlwiXG59XG5cbmZ1bmN0aW9uIHN0cmluZ1RvSFRNTChzdHI6IHN0cmluZyk6IEhUTUxEaXZFbGVtZW50IHsgICAgICAgIC8vdHJhbnNmb3JtZSB1bmUgY2hhaW5lIGRlIGNhcmFjdFx1MDBFOHJlcyBlbiB1biBcdTAwRTlsXHUwMEU5bWVudCBkaXYgaHRtbFxuICAgIHZhciBkaXZfZWx0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgICBkaXZfZWx0LmlubmVySFRNTCA9IHN0clxuICAgIHJldHVybiBkaXZfZWx0XG59XG5cbmZ1bmN0aW9uIGFkZGluZ1JlY2VpdmVkTWVzc2FnZShtZXNzYWdlOiBzdHJpbmcpIHtcbiAgICByZWNlaXZlZF9tZXNzYWdlcy5hcHBlbmQoc3RyaW5nVG9IVE1MKCc8cD48L3A+PHA+PC9wPicgKyBtZXNzYWdlKSlcbn1cblxuLyogTmFtZSBvZiB0aGUgdXNlciBvZiB0aGUgYXBwbGljYXRpb24uLi4gY2FuIGJlIEFsaWNlL0JvYiBmb3IgYXR0YWNraW5nIHB1cnBvc2VzICovXG5sZXQgZ2xvYmFsVXNlck5hbWUgPSBcIlwiXG5cbi8vIFdBUk5JTkchXG4vLyBJdCBpcyBuZWNlc3NhcnkgdG8gcGFzcyB0aGUgVVJMIHBhcmFtZXRlcnMsIGNhbGxlZCBgdXJsUGFyYW1zYCBiZWxvdywgdG8gXG4vLyBldmVyeSBHRVQvUE9TVCBxdWVyeSB5b3Ugc2VuZCB0byB0aGUgc2VydmVyLiBUaGlzIGlzIG1hbmRhdG9yeSB0byBoYXZlIHRoZSBwb3NzaWJpbGl0eSBcbi8vIHRvIHVzZSBhbHRlcm5hdGl2ZSBpZGVudGl0aWVzIGxpa2UgYWxpY2VAdW5pdi1yZW5uZXMuZnIsIGJvYkB1bml2LXJlbm5lcy5mciwgZXRjLiBcbi8vIGZvciBkZWJ1Z2dpbmcgcHVycG9zZXMuXG5hc3luYyBmdW5jdGlvbiBmZXRjaENhc05hbWUoKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCB1cmxQYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHdpbmRvdy5sb2NhdGlvbi5zZWFyY2gpO1xuICAgIGNvbnN0IG5hbWVyZXF1ZXN0ID0gYXdhaXQgZmV0Y2goXCIvZ2V0dXNlcj9cIiArIHVybFBhcmFtcywge1xuICAgICAgICBtZXRob2Q6IFwiR0VUXCIsXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgIFwiQ29udGVudC10eXBlXCI6IFwiYXBwbGljYXRpb24vanNvbjsgY2hhcnNldD1VVEYtOFwiXG4gICAgICAgIH1cbiAgICB9KTtcbiAgICBpZiAoIW5hbWVyZXF1ZXN0Lm9rKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgRXJyb3IhIHN0YXR1czogJHtuYW1lcmVxdWVzdC5zdGF0dXN9YCk7XG4gICAgfVxuICAgIGNvbnN0IG5hbWVSZXN1bHQgPSAoYXdhaXQgbmFtZXJlcXVlc3QuanNvbigpKSBhcyBDYXNVc2VyTmFtZTtcbiAgICByZXR1cm4gbmFtZVJlc3VsdC51c2VybmFtZVxufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRDYXNOYW1lKCkge1xuICAgIGdsb2JhbFVzZXJOYW1lID0gYXdhaXQgZmV0Y2hDYXNOYW1lKClcbiAgICAvLyBXZSByZXBsYWNlIHRoZSBuYW1lIG9mIHRoZSB1c2VyIG9mIHRoZSBhcHBsaWNhdGlvbiBhcyB0aGUgZGVmYXVsdCBuYW1lXG4gICAgLy8gSW4gdGhlIHdpbmRvd1xuICAgIHVzZXJCdXR0b25MYWJlbC50ZXh0Q29udGVudCA9IGdsb2JhbFVzZXJOYW1lXG59XG5cbnNldENhc05hbWUoKVxuXG4vKiBOYW1lIG9mIHRoZSBvd25lci9kZXZlbG9wcGVyIG9mIHRoZSBhcHBsaWNhdGlvbiwgaS5lLCB0aGUgbmFtZSBvZiB0aGUgZm9sZGVyIFxuICAgd2hlcmUgdGhlIHdlYiBwYWdlIG9mIHRoZSBhcHBsaWNhdGlvbiBpcyBzdG9yZWQuIEUuZywgZm9yIHRlYWNoZXJzJyBhcHBsaWNhdGlvblxuICAgdGhpcyBuYW1lIGlzIFwiZW5zXCIgKi9cblxuZnVuY3Rpb24gZ2V0T3duZXJOYW1lKCk6IHN0cmluZyB7XG4gICAgY29uc3QgcGF0aCA9IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZVxuICAgIGNvbnN0IG5hbWUgPSBwYXRoLnNwbGl0KFwiL1wiLCAyKVsxXVxuICAgIHJldHVybiBuYW1lXG59XG5cbmxldCBvd25lck5hbWUgPSBnZXRPd25lck5hbWUoKVxuXG5hc3luYyBmdW5jdGlvbiBmZXRjaEtleSh1c2VyOiBzdHJpbmcsIHB1YmxpY0tleTogYm9vbGVhbiwgZW5jcnlwdGlvbjogYm9vbGVhbik6IFByb21pc2U8Q3J5cHRvS2V5PiB7XG4gICAgLy8gR2V0dGluZyB0aGUgcHVibGljL3ByaXZhdGUga2V5IG9mIHVzZXIuXG4gICAgLy8gRm9yIHB1YmxpYyBrZXkgdGhlIGJvb2xlYW4gJ3B1YmxpY0tleScgaXMgdHJ1ZS5cbiAgICAvLyBGb3IgcHJpdmF0ZSBrZXkgdGhlIGJvb2xlYW4gJ3B1YmxpY0tleScgaXMgZmFsc2UuXG4gICAgLy8gSWYgdGhlIGtleSBpcyB1c2VkIGZvciBlbmNyeXB0aW9uL2RlY3J5cHRpb24gdGhlbiB0aGUgYm9vbGVhbiAnZW5jcnlwdGlvbicgaXMgdHJ1ZS5cbiAgICAvLyBJZiB0aGUga2V5IGlzIHVzZWQgZm9yIHNpZ25hdHVyZS9zaWduYXR1cmUgdmVyaWZpY2F0aW9uIHRoZW4gdGhlIGJvb2xlYW4gaXMgZmFsc2UuXG4gICAgY29uc3Qga2V5UmVxdWVzdE1lc3NhZ2UgPVxuICAgICAgICBuZXcgS2V5UmVxdWVzdCh1c2VyLCBwdWJsaWNLZXksIGVuY3J5cHRpb24pXG4gICAgLy8gRm9yIENBUyBhdXRoZW50aWNhdGlvbiB3ZSBuZWVkIHRvIGFkZCB0aGUgYXV0aGVudGljYXRpb24gdGlja2V0XG4gICAgLy8gSXQgaXMgY29udGFpbmVkIGluIHVybFBhcmFtc1xuICAgIGNvbnN0IHVybFBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMod2luZG93LmxvY2F0aW9uLnNlYXJjaCk7XG4gICAgLy8gRm9yIGdldHRpbmcgYSBrZXkgd2UgZG8gbm90IG5lZWQgdGhlIG93bmVyTmFtZSBwYXJhbVxuICAgIC8vIEJlY2F1c2Uga2V5cyBhcmUgaW5kZXBlbmRhbnQgb2YgdGhlIGFwcGxpY2F0aW9uc1xuICAgIGNvbnN0IGtleXJlcXVlc3QgPSBhd2FpdCBmZXRjaChcIi9nZXRLZXk/XCIgKyB1cmxQYXJhbXMsIHtcbiAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoa2V5UmVxdWVzdE1lc3NhZ2UpLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICBcIkNvbnRlbnQtdHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9VVRGLThcIlxuICAgICAgICB9XG4gICAgfSk7XG4gICAgaWYgKCFrZXlyZXF1ZXN0Lm9rKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgRXJyb3IhIHN0YXR1czogJHtrZXlyZXF1ZXN0LnN0YXR1c31gKTtcbiAgICB9XG4gICAgY29uc3Qga2V5UmVzdWx0ID0gKGF3YWl0IGtleXJlcXVlc3QuanNvbigpKSBhcyBLZXlSZXN1bHQ7XG4gICAgaWYgKCFrZXlSZXN1bHQuc3VjY2VzcykgYWxlcnQoa2V5UmVzdWx0LmVycm9yTWVzc2FnZSlcbiAgICBlbHNlIHtcbiAgICAgICAgaWYgKHB1YmxpY0tleSAmJiBlbmNyeXB0aW9uKSByZXR1cm4gYXdhaXQgc3RyaW5nVG9QdWJsaWNLZXlGb3JFbmNyeXB0aW9uKGtleVJlc3VsdC5rZXkpXG4gICAgICAgIGVsc2UgaWYgKCFwdWJsaWNLZXkgJiYgZW5jcnlwdGlvbikgcmV0dXJuIGF3YWl0IHN0cmluZ1RvUHJpdmF0ZUtleUZvckVuY3J5cHRpb24oa2V5UmVzdWx0LmtleSlcbiAgICAgICAgZWxzZSBpZiAocHVibGljS2V5ICYmICFlbmNyeXB0aW9uKSByZXR1cm4gYXdhaXQgc3RyaW5nVG9QdWJsaWNLZXlGb3JTaWduYXR1cmUoa2V5UmVzdWx0LmtleSlcbiAgICAgICAgZWxzZSBpZiAoIXB1YmxpY0tleSAmJiAhZW5jcnlwdGlvbikgcmV0dXJuIGF3YWl0IHN0cmluZ1RvUHJpdmF0ZUtleUZvclNpZ25hdHVyZShrZXlSZXN1bHQua2V5KVxuICAgIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gc2VuZE1lc3NhZ2UoYWdlbnROYW1lOiBzdHJpbmcsIHJlY2VpdmVyTmFtZTogc3RyaW5nLCBtZXNzYWdlQ29udGVudDogc3RyaW5nKTogUHJvbWlzZTxTZW5kUmVzdWx0PiB7XG4gICAgdHJ5IHtcbiAgICAgICAgbGV0IG1lc3NhZ2VUb1NlbmQgPVxuICAgICAgICAgICAgbmV3IEV4dE1lc3NhZ2UoYWdlbnROYW1lLCByZWNlaXZlck5hbWUsIG1lc3NhZ2VDb250ZW50KVxuICAgICAgICBjb25zdCB1cmxQYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKHdpbmRvdy5sb2NhdGlvbi5zZWFyY2gpO1xuXG4gICAgICAgIGNvbnN0IHJlcXVlc3QgPSBhd2FpdCBmZXRjaChcIi9zZW5kaW5nTWVzc2FnZS9cIiArIG93bmVyTmFtZSArIFwiP1wiICsgdXJsUGFyYW1zLCB7XG4gICAgICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkobWVzc2FnZVRvU2VuZCksXG4gICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgXCJDb250ZW50LXR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uOyBjaGFyc2V0PVVURi04XCJcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGlmICghcmVxdWVzdC5vaykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFcnJvciEgc3RhdHVzOiAke3JlcXVlc3Quc3RhdHVzfWApO1xuICAgICAgICB9XG4gICAgICAgIC8vIERlYWxpbmcgd2l0aCB0aGUgYW5zd2VyIG9mIHRoZSBtZXNzYWdlIHNlcnZlclxuICAgICAgICByZXR1cm4gKGF3YWl0IHJlcXVlc3QuanNvbigpKSBhcyBTZW5kUmVzdWx0XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ2Vycm9yIG1lc3NhZ2U6ICcsIGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBTZW5kUmVzdWx0KGZhbHNlLCBlcnJvci5tZXNzYWdlKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ3VuZXhwZWN0ZWQgZXJyb3I6ICcsIGVycm9yKTtcbiAgICAgICAgICAgIHJldHVybiBuZXcgU2VuZFJlc3VsdChmYWxzZSwgJ0FuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWQnKVxuICAgICAgICB9XG4gICAgfVxufVxuXG4vLyBmdW5jdGlvbiBmb3IgcmVmcmVzaGluZyB0aGUgY29udGVudCBvZiB0aGUgd2luZG93IChhdXRvbWF0aWMgb3IgbWFudWFsIHNlZSBiZWxvdylcbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2goKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgdXNlciA9IGdsb2JhbFVzZXJOYW1lXG4gICAgICAgIGNvbnN0IGhpc3RvcnlSZXF1ZXN0ID1cbiAgICAgICAgICAgIG5ldyBIaXN0b3J5UmVxdWVzdCh1c2VyLCBsYXN0SW5kZXhJbkhpc3RvcnkpXG4gICAgICAgIGNvbnN0IHVybFBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMod2luZG93LmxvY2F0aW9uLnNlYXJjaCk7XG4gICAgICAgIGNvbnN0IHJlcXVlc3QgPSBhd2FpdCBmZXRjaChcIi9oaXN0b3J5L1wiICsgb3duZXJOYW1lICsgXCI/XCIgKyB1cmxQYXJhbXNcbiAgICAgICAgICAgICwge1xuICAgICAgICAgICAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoaGlzdG9yeVJlcXVlc3QpLFxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICAgICAgXCJDb250ZW50LXR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uOyBjaGFyc2V0PVVURi04XCJcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgaWYgKCFyZXF1ZXN0Lm9rKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEVycm9yISBzdGF0dXM6ICR7cmVxdWVzdC5zdGF0dXN9IGApO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IChhd2FpdCByZXF1ZXN0Lmpzb24oKSkgYXMgSGlzdG9yeUFuc3dlclxuICAgICAgICBpZiAoIXJlc3VsdC5zdWNjZXNzKSB7IGFsZXJ0KHJlc3VsdC5mYWlsdXJlTWVzc2FnZSkgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIC8vIFRoaXMgaXMgdGhlIHBsYWNlIHdoZXJlIHlvdSBjYW4gcGVyZm9ybSB0cmlnZ2VyIGFueSBvcGVyYXRpb25zIGZvciByZWZyZXNoaW5nIHRoZSBwYWdlXG4gICAgICAgICAgICBsYXN0SW5kZXhJbkhpc3RvcnkgPSByZXN1bHQuaW5kZXhcbiAgICAgICAgICAgIGlmIChyZXN1bHQuYWxsTWVzc2FnZXMubGVuZ3RoICE9IDApIHtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBtIG9mIHJlc3VsdC5hbGxNZXNzYWdlcykgeyAgICAgICAgIC8vcG91ciBjaGFxdWUgbWVzc2FnZSBtXG4gICAgICAgICAgICAgICAgICAgIGxldCBbYiwgdHlwZSAsIHNlbmRlciwgcmVjZWl2ZXIsIG1zZ0NvbnRlbnQsIG5vdWNlLCBub3VuY2VPZlJlY2VpdmVyXSA9IGF3YWl0IGFuYWx5c2VNZXNzYWdlKG0pXG4gICAgICAgICAgICAgICAgICAgIGlmIChiICYmICh0eXBlID09IDEpKSB7IGN1cnJlbnROb3VjZSA9IGdlbmVyYXRlTm9uY2UoKSA7IGNvbnN0cnVjdE1lc3NhZ2UoMiwgdXNlciwgc2VuZGVyLCBcIlwiLCBjdXJyZW50Tm91Y2UpfSAgICAgICAvL3BhcnRpZSAxXG4gICAgICAgICAgICAgICAgICAgIC8vcXVhbmQgQiByZVx1MDBFN29pdCBsZSBcImhleVwiIGRlIEEsIGlsIGdcdTAwRTluXHUwMEU4cmUgdW4gbm9uY2UgcXUnaWwgbHVpIGVudm9pZVxuXG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGIgJiYgKHR5cGUgPT0gMikpIHtyZWNlaXZlTm91bmNlID0gdHJ1ZSwgbm91Y2VHbG9iYWwgPSBub3VjZX0gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL3BhcnRpZSAyXG4gICAgICAgICAgICAgICAgICAgIC8vb24gc2V0IGxlIG5vbmNlIGNvbW1lIHZhcmlhYmxlIGdsb2JhbGUgZXQgb24gdXBkYXRlIGxhIHJcdTAwRTljZXB0aW9uIGR1IG5vbmNlIGNcdTAwRjR0XHUwMEU5IEFcblxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChiICYmIHZlcmlmeU5vdW5jZShub3VjZSwgY3VycmVudE5vdWNlKSAmJiAodHlwZSA9PSAzKSkgeyBhY3Rpb25Pbk1lc3NhZ2VPbmUoc2VuZGVyLCByZWNlaXZlciwgbXNnQ29udGVudCksIGNvbnN0cnVjdE1lc3NhZ2UoNSwgdXNlciwgc2VuZGVyLCBcIlwiLCBub3VuY2VPZlJlY2VpdmVyLFwiXCIpfSAgICAgLy9wYXJ0aWUgM1xuICAgICAgICAgICAgICAgICAgICAvL3NpIEIgcmVcdTAwRTdvaXQgbGUgbVx1MDBFQW1lIG5vbmNlIHF1ZSBjZWx1aSBxdSdpbCBhIGdcdTAwRTluXHUwMEU5clx1MDBFOSwgaWwgYXV0aGVudGlmaWUgQSBldCBwZXV0IGNvbnNpZFx1MDBFOXJlciBsZSBtZXNzYWdlIHNlY3JldCByZVx1MDBFN3UuXG5cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoYiAmJiAodHlwZSA9PSA0KSkgeyBjb25zb2xlLmxvZyhcIkhpc3RvcmljXCIpIDsgYWN0aW9uT25NZXNzYWdlT25lKHNlbmRlciwgcmVjZWl2ZXIsIG1zZ0NvbnRlbnQpfSAgICAgICAgLy9wYXJ0aWUgNFxuICAgICAgICAgICAgICAgICAgICAvL3BvdXIgbCdoaXN0b3JpcXVlIFxuXG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGIgJiYgKHR5cGUgPT0gNSkgJiYgdmVyaWZ5Tm91bmNlKG5vdWNlLGNvbmZpcm1hdGlvbk5vdWNlKSkgeyBjb25zb2xlLmxvZyhcIkNvbmZpcm1hdGlvbiBSZWNlcHRpb25cIikgfVxuXG4gICAgICAgICAgICAgICAgICAgIGVsc2UgY29uc29sZS5sb2coXCJNc2cgXCIgKyBtLnNlbmRlciArIFwiIC0+IFwiICsgbS5yZWNlaXZlciArIFwiIDogXCIgKyBtLmNvbnRlbnQgKyBcIiBjYW5ub3QgYmUgZXhwbG9pdGVkIGJ5IFwiICsgdXNlcikgXG4gICAgICAgICAgICAgICAgICAgIC8vc2kgaW1wclx1MDBFOXZ1L2VycmV1clxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdlcnJvciBtZXNzYWdlOiAnLCBlcnJvci5tZXNzYWdlKTtcbiAgICAgICAgICAgIHJldHVybiBlcnJvci5tZXNzYWdlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ3VuZXhwZWN0ZWQgZXJyb3I6ICcsIGVycm9yKTtcbiAgICAgICAgICAgIHJldHVybiAnQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZCc7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi8vIEF1dG9tYXRpYyByZWZyZXNoXG5jb25zdCBpbnRlcnZhbFJlZnJlc2ggPSBzZXRJbnRlcnZhbChyZWZyZXNoLCAyMDAwKVxuXG4vLy0tLS0tLS0tLSBEXHUwMEU5YnV0IGRlIG5vdHJlIGNvZGUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuLy8gICAgICBDT1RFIFNFTkRFUlxuLy9lbnZvaSBkdSBtZXNzYWdlIHF1YW5kIG9uIGNsaXF1ZSBzdXIgc2VuZFxuc2VuZEJ1dHRvbi5vbmNsaWNrID0gYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgIGNvbnNvbGUubG9nKFwiQm91dHRvbiBjbGlja2VkXCIpXG4gICAgbGV0IGFnZW50TmFtZSA9IGdsb2JhbFVzZXJOYW1lICAgICAgLy9ub20gZHUgc2VuZGVyIGFsaWNlXG4gICAgbGV0IHJlY2VpdmVyTmFtZSA9IHJlY2VpdmVyLnZhbHVlICAgICAgLy9ub20gZHUgcmVjZXZldXIgYm9iXG4gICAgbGV0IGkgPSAwO1xuICAgIGNvbnN0cnVjdE1lc3NhZ2UoMSxhZ2VudE5hbWUsIHJlY2VpdmVyTmFtZSwgXCJoZXlcIiwgXCJcIikgICAgICAvL0EgaW5pdGllIGxlIHByb3RvY29sZSBlbiBlbnZveWFudCBcImhleVwiIFx1MDBFMCBCXG4gICAgY29uc29sZS5sb2coXCJQcm90byAxXCIpXG5cbiAgICB3aGlsZSAoaSA8IDEwICYmIHJlY2VpdmVOb3VuY2UgPT0gZmFsc2UpIHsgICAgICAgICAgICAgICAgICAvL2F0dGVudGUgZGUgclx1MDBFOWNlcHRpb24gZHUgbm9uY2UgZ1x1MDBFOW5cdTAwRTlyXHUwMEU5IHBhciBCXG4gICAgICAgIGF3YWl0IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCAyMDAwMCkpOyBcbiAgICAgICAgY29uc29sZS5sb2coXCJXYWl0aW5nIGZvciB0aGUgbm91bmNlXCIpXG4gICAgICAgIGkrKztcbiAgICB9XG4gICAgaSA9IDA7XG5cbiAgICBpZiAocmVjZWl2ZU5vdW5jZSA9PSB0cnVlKXsgICAgICAgICAgICAgLy9xdWFuZCBvbiBhIHJlXHUwMEU3dSBsZSBub25jZVxuICAgICAgICBjb25zb2xlLmxvZyhcIk5vdW5jZSByZWNlaXZlZFwiICsgbm91Y2VHbG9iYWwpXG4gICAgICAgIGNvbmZpcm1hdGlvbk5vdWNlID0gZ2VuZXJhdGVOb25jZSgpICAgICAgICAvL0EgZ1x1MDBFOW5cdTAwRThyZSB1biBub25jZSBxdSdpbCBlbnZvaWUgXHUwMEUwIEIgcG91ciBjb25maXJtZXIgbGEgclx1MDBFOWNlcHRpb24gZHUgbm9uY2VcbiAgICAgICAgY29uc3RydWN0TWVzc2FnZSgzLGFnZW50TmFtZSwgcmVjZWl2ZXJOYW1lLCBtZXNzYWdlLnZhbHVlLCBub3VjZUdsb2JhbCwgY29uZmlybWF0aW9uTm91Y2UpICAgICAvL0EgZW52b2llIFx1MDBFMCBCIGxlIHNlY3JldCBhaW5zaSBxdWUgbGUgbm9uY2UgcXUnaWwgdmllbnQgZGUgcmVjZXZvaXJcbiAgICAgICAgc2VsZlNhdmVIaXN0b3J5KDQsIGFnZW50TmFtZSwgcmVjZWl2ZXJOYW1lLCBtZXNzYWdlLnZhbHVlLCBub3VjZUdsb2JhbCkgICAgIC8vQSBzYXV2ZWdhcmRlIGxlIG1lc3NhZ2UgZW52b3lcdTAwRTkgZGFucyBzb24gaGlzdG9yaXF1ZVxuICAgICAgICBjb25zb2xlLmxvZyhcIlByb3RvIDNcIilcbiAgICB9XG5cbiAgICBpID0gMDtcblxuXG4gICAgbm91Y2VHbG9iYWwgPSBcIlwiOyAgICAgICAgICAgICAgIC8vcmVzZXQgZGUgclx1MDBFOWNlcHRpb24gZHUgbm9uY2UgKGNoYXF1ZSBtZXNzYWdlIFx1MDBFOWNoYW5nXHUwMEU5IGdcdTAwRTluXHUwMEU4cmUgdW4gbm91dmVhdSBub25jZSlcbiAgICByZWNlaXZlTm91bmNlID0gZmFsc2Vcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2VsZlNhdmVIaXN0b3J5IChtZXNzYWdlVHlwZSA6IG51bWJlciwgYWdlbnROYW1lIDogc3RyaW5nLCByZWNlaXZlck5hbWUgOiBzdHJpbmcsIG1lc3NhZ2UgOiBzdHJpbmcsIG5vdWNlIDogc3RyaW5nKSB7ICAgIC8vaGlzdG9yaXF1ZSBkZXMgbWVzc2FnZXNcbiAgICBsZXQgY29udGVudFRvRW5jcnlwdCA9IEpTT04uc3RyaW5naWZ5KFttZXNzYWdlVHlwZSAsYWdlbnROYW1lLCByZWNlaXZlck5hbWUsIG1lc3NhZ2UsIG5vdWNlXSkgXG5cbiAgICBjb25zdCBrYSA9IGF3YWl0IGZldGNoS2V5KGFnZW50TmFtZSwgdHJ1ZSwgdHJ1ZSkgXG4gICAgY29uc3QgZW5jcnlwdGVkTWVzc2FnZSA9IGF3YWl0IGVuY3J5cHRXaXRoUHVibGljS2V5KGthLCBjb250ZW50VG9FbmNyeXB0KVxuICAgIGNvbnN0IHNlbmRSZXN1bHQgPSBhd2FpdCBzZW5kTWVzc2FnZShhZ2VudE5hbWUsIGFnZW50TmFtZSwgZW5jcnlwdGVkTWVzc2FnZSlcblxuICAgIGlmICghc2VuZFJlc3VsdC5zdWNjZXNzKSBcbiAgICAgICAge2NvbnNvbGUubG9nKHNlbmRSZXN1bHQuZXJyb3JNZXNzYWdlKX1cbiAgICBcbiAgICAgICAgZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiU3VjY2Vzc2Z1bGx5IHNhdmUhXCIpXG4gICAgfVxuICAgICAgICAgICAgXG4gICAgXG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNvbnN0cnVjdE1lc3NhZ2UobWVzc2FnZVR5cGUgOiBudW1iZXIsIGFnZW50TmFtZSA6IHN0cmluZywgcmVjZWl2ZXJOYW1lIDogc3RyaW5nLCBtZXNzYWdlIDogc3RyaW5nLCBub3VjZSA6IHN0cmluZywgY29uZmlybWF0aW9uTm91Y2UgOiBzdHJpbmcgPSBcIlwiKSB7ICAgLy9tZXNzYWdlVHlwZSA9IDEsMiwzLDQsNVxuICAgIFxuICAgIGxldCBjb250ZW50VG9FbmNyeXB0ID0gSlNPTi5zdHJpbmdpZnkoW21lc3NhZ2VUeXBlICxhZ2VudE5hbWUsIHJlY2VpdmVyTmFtZSwgbWVzc2FnZSwgbm91Y2UsIGNvbmZpcm1hdGlvbk5vdWNlXSkgICAvL1thbGljZSwgYm9iLCBtXVxuICAgIHRyeSB7XG4gICAgICAgIC8vXG4gICAgICAgIC8vIFwiR2V0dGluZyB0aGUgcHVibGljL3ByaXZhdGUga2V5IG9mIHVzZXIuXG4gICAgICAgIC8vIEZvciBwdWJsaWMga2V5IHRoZSBib29sZWFuICdwdWJsaWNLZXknIGlzIHRydWUuXG4gICAgICAgIC8vIEZvciBwcml2YXRlIGtleSB0aGUgYm9vbGVhbiAncHVibGljS2V5JyBpcyBmYWxzZS5cbiAgICAgICAgLy8gSWYgdGhlIGtleSBpcyB1c2VkIGZvciBlbmNyeXB0aW9uL2RlY3J5cHRpb24gdGhlbiB0aGUgYm9vbGVhbiAnZW5jcnlwdGlvbicgaXMgdHJ1ZS5cbiAgICAgICAgLy8gSWYgdGhlIGtleSBpcyB1c2VkIGZvciBzaWduYXR1cmUvc2lnbmF0dXJlIHZlcmlmaWNhdGlvbiB0aGVuIHRoZSBib29sZWFuIGlzIGZhbHNlLlwiXCJcbiAgICAgICAgY29uc3Qga2IgPSBhd2FpdCBmZXRjaEtleShyZWNlaXZlck5hbWUsIHRydWUsIHRydWUpIC8vY2xcdTAwRTkgcHVibGlxdWUgZXQgZW5jcnlwdGlvbiBkb25jIHRydWUsIHRydWVcbiAgICAgICAgLy8gb24gY2hpZmZyZSBtXG4gICAgICAgIGNvbnN0IGVuY3J5cHRlZE1lc3NhZ2UgPSBhd2FpdCBlbmNyeXB0V2l0aFB1YmxpY0tleShrYiwgY29udGVudFRvRW5jcnlwdClcbiAgICAgICAgLy8gb24gZW52b2llIG1cbiAgICAgICAgY29uc3Qgc2VuZFJlc3VsdCA9IGF3YWl0IHNlbmRNZXNzYWdlKGFnZW50TmFtZSwgcmVjZWl2ZXJOYW1lLCBlbmNyeXB0ZWRNZXNzYWdlKVxuXG4gICAgICAgIGlmICghc2VuZFJlc3VsdC5zdWNjZXNzKSBjb25zb2xlLmxvZyhzZW5kUmVzdWx0LmVycm9yTWVzc2FnZSlcbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIlN1Y2Nlc3NmdWxseSBzZW50IHRoZSBtZXNzYWdlIVwiKVxuICAgICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdlcnJvciBtZXNzYWdlOiAnLCBlLm1lc3NhZ2UpXG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCd1bmV4cGVjdGVkIGVycm9yOiAnLCBlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFxuICAgIH1cbiAgICAgICAgXG59XG5cbi8vIFJldHVybmluZyBhIHN0cmluZyByZXByZXNlbnRpbmcgdGhlIGN1cnJlbnQgdGltZSBpbiB0aGUgZm9ybWF0XG4vLyBISDpNTTpTU1xuZnVuY3Rpb24gcmVhZGFibGVUaW1lKCk6IHN0cmluZyB7XG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKVxuICAgIGNvbnN0IGhvdXJzID0gbm93LmdldEhvdXJzKCkudG9TdHJpbmcoKVxuICAgIGNvbnN0IG1pbnV0ZXMgPSBub3cuZ2V0TWludXRlcygpLnRvU3RyaW5nKClcbiAgICBjb25zdCBzZWNvbmRzID0gbm93LmdldFNlY29uZHMoKS50b1N0cmluZygpXG4gICAgLy8gU2luY2UgZ2V0SG91cnMoKSBldGMgcmV0dXJuIGEgZGVjaW1hbCBjb3VudCBmb3IgaG91cnMsIGV0Yy4gd2UgZXhwbGljaXRlbHkgYWRkIDAgd2hlbiB0aGVyZVxuICAgIC8vIGFyZSBubyB0ZW5zIGRpZ2l0LlxuICAgIHJldHVybiBgJHsoaG91cnMubGVuZ3RoID09PSAxKSA/IFwiMFwiICsgaG91cnMgOiBob3Vyc306JHsobWludXRlcy5sZW5ndGggPT09IDEpID8gXCIwXCIgKyBtaW51dGVzIDogbWludXRlc306JHsoc2Vjb25kcy5sZW5ndGggPT09IDEpID8gXCIwXCIgKyBzZWNvbmRzIDogc2Vjb25kc31gXG59XG5cbi8vLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vQ09URSBSRUNFSVZFUlxuLy8tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy9xdWFuZCBsZSByZWNldmV1ciByZVx1MDBFN29pdCBsZSBtZXNzYWdlXG5hc3luYyBmdW5jdGlvbiBhbmFseXNlTWVzc2FnZShtZXNzYWdlOiBFeHRNZXNzYWdlKTogUHJvbWlzZTxbYm9vbGVhbiwgbnVtYmVyLCBzdHJpbmcgLHN0cmluZywgc3RyaW5nLCBzdHJpbmcsIHN0cmluZ10+IHtcbiAgICBjb25zdCB1c2VyID0gZ2xvYmFsVXNlck5hbWVcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBtZXNzYWdlU2VuZGVyID0gbWVzc2FnZS5zZW5kZXJcbiAgICAgICAgY29uc3QgbWVzc2FnZUNvbnRlbnQgPSBtZXNzYWdlLmNvbnRlbnRcbiAgICAgICAgaWYgKG1lc3NhZ2UucmVjZWl2ZXIgIT09IHVzZXIpIHtcbiAgICAgICAgICAgIC8vIElmIHRoZSBtZXNzYWdlIGlzIG5vdCBzZW50IHRvIHRoZSB1c2VyLCB3ZSBkbyBub3QgY29uc2lkZXIgaXRcbiAgICAgICAgICAgIHJldHVybiBbZmFsc2UsIDAgLFwiXCIsIFwiXCIsIFwiXCIsXCJcIiwgXCJcIl1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgLy9vbiByXHUwMEU5Y3VwIGxhIGNsXHUwMEU5IHByaXZcdTAwRTllIGRlIGIgcG91ciBkXHUwMEU5Y2hpZmZyZXIgLT4gZmFsc2UsIHRydWVcbiAgICAgICAgICAgICAgICBjb25zdCBwcml2a2V5ID0gYXdhaXQgZmV0Y2hLZXkodXNlciwgZmFsc2UsIHRydWUpXG4gICAgICAgICAgICAgICAgY29uc3QgbWVzc2FnZUluQ2xlYXJTdHJpbmcgPSBhd2FpdCBkZWNyeXB0V2l0aFByaXZhdGVLZXkocHJpdmtleSwgbWVzc2FnZUNvbnRlbnQpICAgICAgIC8vb24gclx1MDBFOWN1cCAobnVtYmVyLCBzdHJpbmcsIHN0cmluZywgc3RyaW5nLCBzdHJpbmcpXG5cbiAgICAgICAgICAgICAgICBjb25zdCBtZXNzYWdlQXJyYXlJbkNsZWFyID0gSlNPTi5wYXJzZShtZXNzYWdlSW5DbGVhclN0cmluZykgYXMgc3RyaW5nW10gICAgICAgIC8vb24gcGFyc2UgbGUgdG91dCBldCBvbiBpc29sZSBjaGFxdWUgXHUwMEU5bFx1MDBFOW1lbnRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIGNvbnN0IG1lc3NhZ2VUeXBlSW5NZXNzYWdlID0gTnVtYmVyKG1lc3NhZ2VBcnJheUluQ2xlYXJbMF0pICAgICAgICAgLy9pY2kgbGUgdHlwZSAoZFx1MDBFOWZpbml0IGwnXHUwMEU5dGFwZSBkdSBwcm90b2NvbGUpXG4gICAgICAgICAgICAgICAgY29uc3QgbWVzc2FnZVNlbmRlckluTWVzc2FnZSA9IG1lc3NhZ2VBcnJheUluQ2xlYXJbMV0gICAgICAgLy9zZW5kZXIgPSBhbGljZSBkYW5zIGwnZXhlbXBsZVxuICAgICAgICAgICAgICAgIGNvbnN0IG1lc3NhZ2VSZWNlaXZlckluTWVzc2FnZSA9IG1lc3NhZ2VBcnJheUluQ2xlYXJbMl0gICAgICAgICAgIC8vcmVjZWl2ZXIgPSBib2IgICBcbiAgICAgICAgICAgICAgICBjb25zdCBtZXNzYWdlSW5DbGVhciA9IG1lc3NhZ2VBcnJheUluQ2xlYXJbM10gICAgICAgICAgIC8vbWVzc2FnZSA9IG1cbiAgICAgICAgICAgICAgICBjb25zdCBub3VjZUluTWVzc2FnZSA9IChtZXNzYWdlQXJyYXlJbkNsZWFyWzRdKSAgICAgICAgIC8vZXQgbGUgbm9uY2VcbiAgICAgICAgICAgICAgICBjb25zdCBjb25maXJtYXRpb25Ob3VjZUluTWVzc2FnZSA9IChtZXNzYWdlQXJyYXlJbkNsZWFyWzVdKSAgICAgICAgIC8vZXQgbGUgbm9uY2UgZGUgY29uZmlybWF0aW9uXG5cbiAgICAgICAgICAgICAgICBpZiAobWVzc2FnZVNlbmRlckluTWVzc2FnZSA9PSBtZXNzYWdlU2VuZGVyIHx8IG1lc3NhZ2VSZWNlaXZlckluTWVzc2FnZSA9PSBnbG9iYWxVc2VyTmFtZSkgeyAgICAgIC8vc2kgbGUgc2VuZGVyIGVzdCBsZSBtXHUwMEVBbWUgZGFucyBsZSBtZXNzYWdlIGV0IGRhbnMgbGUgdGFibGVhdSBjJ2VzdCBnb29kXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbdHJ1ZSwgbWVzc2FnZVR5cGVJbk1lc3NhZ2UgLG1lc3NhZ2VTZW5kZXJJbk1lc3NhZ2UsIG1lc3NhZ2VSZWNlaXZlckluTWVzc2FnZSwgZXZhbChcImAoJHtyZWFkYWJsZVRpbWUoKX0pIFwiICsgbWVzc2FnZUluQ2xlYXIgKyBcImBcIiksIG5vdWNlSW5NZXNzYWdlLCBjb25maXJtYXRpb25Ob3VjZUluTWVzc2FnZV0gICAvL29uIHJlbnZvaWUgbGUgbWVzc2FnZSBlbiBjbGFpclxuICAgICAgICAgICAgICAgIH0gICAvL2VzdC1jZSBxdSdvbiBwZXV0IHRyb3V2ZXIgdW5lIGFsdGVybmF0aXZlIHNpbXBsZSBhdSBldmFsID9cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJSZWFsIG1lc3NhZ2Ugc2VuZGVyIGFuZCBtZXNzYWdlIHNlbmRlciBuYW1lIGluIHRoZSBtZXNzYWdlIGRvIG5vdCBjb2luY2lkZVwiKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImFuYWx5c2VNZXNzYWdlOiBkZWNyeXB0aW9uIGZhaWxlZCBiZWNhdXNlIG9mIFwiICsgZSlcbiAgICAgICAgICAgICAgICByZXR1cm4gW2ZhbHNlLCAtMSAsIFwiXCIsIFwiXCIsIFwiXCIsIFwiXCIsIFwiXCJdXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiYW5hbHlzZU1lc3NhZ2U6IGRlY3J5cHRpb24gZmFpbGVkIGJlY2F1c2Ugb2YgXCIgKyBlKVxuICAgICAgICByZXR1cm4gW2ZhbHNlLCAwLCBcIlwiLCBcIlwiLCBcIlwiLCBcIlwiLCBcIlwiXVxuICAgIH1cbn1cblxuICBcbmZ1bmN0aW9uIGFjdGlvbk9uTWVzc2FnZU9uZShmcm9tQTogc3RyaW5nLCBUb0I6IHN0cmluZywgbWVzc2FnZUNvbnRlbnQ6IHN0cmluZykge1xuICAgIGNvbnN0IHVzZXIgPSBnbG9iYWxVc2VyTmFtZSAgICAgICAgIFxuICAgIGNvbnNvbGUubG9nKFwiYWN0aW9uT25NZXNzYWdlT25lOiBcIiArIGZyb21BICsgXCIgLT4gXCIgKyBUb0IgKyBcIiA6IFwiICsgbWVzc2FnZUNvbnRlbnQpXG4gICAgaWYgKGZyb21BID09PSB1c2VyKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiTGUgbWVzc2FnZSB2aWVudCBkZSBsJ3V0aWxpc2F0ZXVyIGx1aS1tXHUwMEVBbWUuXCIpXG4gICAgICAgIGNvbnN0IHRleHRUb0FkZCA9IGA8Zm9udCBjb2xvcj1cImJsdWVcIj4gJHtmcm9tQX0gLT4gJHtUb0J9IDogJHttZXNzYWdlQ29udGVudH0gPC9mb250PmBcbiAgICAgICAgYWRkaW5nUmVjZWl2ZWRNZXNzYWdlKHRleHRUb0FkZClcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiTWVzc2FnZSB2ZW5hbnQgZCd1biBhdXRyZSB1dGlsaXNhdGV1ci5cIilcbiAgICAgICAgY29uc3QgdGV4dFRvQWRkID0gYCR7ZnJvbUF9IC0+ICR7VG9CfSA6ICR7bWVzc2FnZUNvbnRlbnR9IGBcbiAgICAgICAgYWRkaW5nUmVjZWl2ZWRNZXNzYWdlKHRleHRUb0FkZClcbiAgICB9XG4gICAgXG59XG4gXG5cbmZ1bmN0aW9uIHZlcmlmeU5vdW5jZShub3VuY2VPZlNlbmRlcjogc3RyaW5nLCBub3VuY2VPZlJlY2VpdmVyOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICByZXR1cm4gTnVtYmVyKG5vdW5jZU9mU2VuZGVyKSA9PSBOdW1iZXIobm91bmNlT2ZSZWNlaXZlcikgO1xuXG59XG5cblxuXG4iXSwKICAibWFwcGluZ3MiOiAiO0FBMENBLGVBQXNCLCtCQUErQixZQUF3QztBQUN6RixNQUFJO0FBQ0EsVUFBTSxpQkFBOEIsMEJBQTBCLFVBQVU7QUFDeEUsVUFBTSxNQUFpQixNQUFNLE9BQU8sT0FBTyxPQUFPO0FBQUEsTUFDOUM7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLFFBQ0ksTUFBTTtBQUFBLFFBQ04sTUFBTTtBQUFBLE1BQ1Y7QUFBQSxNQUNBO0FBQUEsTUFDQSxDQUFDLFNBQVM7QUFBQSxJQUNkO0FBQ0EsV0FBTztBQUFBLEVBQ1gsU0FBUyxHQUFHO0FBQ1IsUUFBSSxhQUFhLGNBQWM7QUFBRSxjQUFRLElBQUksMkRBQTJEO0FBQUEsSUFBRSxXQUNqRyxhQUFhLG9CQUFvQjtBQUFFLGNBQVEsSUFBSSwyREFBMkQ7QUFBQSxJQUFFLE9BQ2hIO0FBQUUsY0FBUSxJQUFJLENBQUM7QUFBQSxJQUFFO0FBQ3RCLFVBQU07QUFBQSxFQUNWO0FBQ0o7QUFNQSxlQUFzQiw4QkFBOEIsWUFBd0M7QUFDeEYsTUFBSTtBQUNBLFVBQU0saUJBQThCLDBCQUEwQixVQUFVO0FBQ3hFLFVBQU0sTUFBaUIsTUFBTSxPQUFPLE9BQU8sT0FBTztBQUFBLE1BQzlDO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxRQUNJLE1BQU07QUFBQSxRQUNOLE1BQU07QUFBQSxNQUNWO0FBQUEsTUFDQTtBQUFBLE1BQ0EsQ0FBQyxRQUFRO0FBQUEsSUFDYjtBQUNBLFdBQU87QUFBQSxFQUNYLFNBQVMsR0FBRztBQUNSLFFBQUksYUFBYSxjQUFjO0FBQUUsY0FBUSxJQUFJLHVFQUF1RTtBQUFBLElBQUUsV0FDN0csYUFBYSxvQkFBb0I7QUFBRSxjQUFRLElBQUksdUVBQXVFO0FBQUEsSUFBRSxPQUM1SDtBQUFFLGNBQVEsSUFBSSxDQUFDO0FBQUEsSUFBRTtBQUN0QixVQUFNO0FBQUEsRUFDVjtBQUNKO0FBTUEsZUFBc0IsZ0NBQWdDLFlBQXdDO0FBQzFGLE1BQUk7QUFDQSxVQUFNLGlCQUE4QiwwQkFBMEIsVUFBVTtBQUN4RSxVQUFNLE1BQWlCLE1BQU0sT0FBTyxPQUFPLE9BQU87QUFBQSxNQUM5QztBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsUUFDSSxNQUFNO0FBQUEsUUFDTixNQUFNO0FBQUEsTUFDVjtBQUFBLE1BQ0E7QUFBQSxNQUNBLENBQUMsU0FBUztBQUFBLElBQUM7QUFDZixXQUFPO0FBQUEsRUFDWCxTQUFTLEdBQUc7QUFDUixRQUFJLGFBQWEsY0FBYztBQUFFLGNBQVEsSUFBSSw0REFBNEQ7QUFBQSxJQUFFLFdBQ2xHLGFBQWEsb0JBQW9CO0FBQUUsY0FBUSxJQUFJLDREQUE0RDtBQUFBLElBQUUsT0FDakg7QUFBRSxjQUFRLElBQUksQ0FBQztBQUFBLElBQUU7QUFDdEIsVUFBTTtBQUFBLEVBQ1Y7QUFDSjtBQU1BLGVBQXNCLCtCQUErQixZQUF3QztBQUN6RixNQUFJO0FBQ0EsVUFBTSxpQkFBOEIsMEJBQTBCLFVBQVU7QUFDeEUsVUFBTSxNQUFpQixNQUFNLE9BQU8sT0FBTyxPQUFPO0FBQUEsTUFDOUM7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLFFBQ0ksTUFBTTtBQUFBLFFBQ04sTUFBTTtBQUFBLE1BQ1Y7QUFBQSxNQUNBO0FBQUEsTUFDQSxDQUFDLE1BQU07QUFBQSxJQUFDO0FBQ1osV0FBTztBQUFBLEVBQ1gsU0FBUyxHQUFHO0FBQ1IsUUFBSSxhQUFhLGNBQWM7QUFBRSxjQUFRLElBQUksMkRBQTJEO0FBQUEsSUFBRSxXQUNqRyxhQUFhLG9CQUFvQjtBQUFFLGNBQVEsSUFBSSwyREFBMkQ7QUFBQSxJQUFFLE9BQ2hIO0FBQUUsY0FBUSxJQUFJLENBQUM7QUFBQSxJQUFFO0FBQ3RCLFVBQU07QUFBQSxFQUNWO0FBQ0o7QUFNQSxlQUFzQixrQkFBa0IsS0FBaUM7QUFDckUsUUFBTSxjQUEyQixNQUFNLE9BQU8sT0FBTyxPQUFPLFVBQVUsUUFBUSxHQUFHO0FBQ2pGLFNBQU8sMEJBQTBCLFdBQVc7QUFDaEQ7QUFNQSxlQUFzQixtQkFBbUIsS0FBaUM7QUFDdEUsUUFBTSxjQUEyQixNQUFNLE9BQU8sT0FBTyxPQUFPLFVBQVUsU0FBUyxHQUFHO0FBQ2xGLFNBQU8sMEJBQTBCLFdBQVc7QUFDaEQ7QUFHQSxlQUFzQixzQ0FBNEQ7QUFDOUUsUUFBTSxVQUF5QixNQUFNLE9BQU8sT0FBTyxPQUFPO0FBQUEsSUFDdEQ7QUFBQSxNQUNJLE1BQU07QUFBQSxNQUNOLGVBQWU7QUFBQSxNQUNmLGdCQUFnQixJQUFJLFdBQVcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0FBQUEsTUFDeEMsTUFBTTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsSUFDQSxDQUFDLFdBQVcsU0FBUztBQUFBLEVBQ3pCO0FBQ0EsU0FBTyxDQUFDLFFBQVEsV0FBVyxRQUFRLFVBQVU7QUFDakQ7QUFHQSxlQUFzQixxQ0FBMkQ7QUFDN0UsUUFBTSxVQUF5QixNQUFNLE9BQU8sT0FBTyxPQUFPO0FBQUEsSUFDdEQ7QUFBQSxNQUNJLE1BQU07QUFBQSxNQUNOLGVBQWU7QUFBQSxNQUNmLGdCQUFnQixJQUFJLFdBQVcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0FBQUEsTUFDeEMsTUFBTTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsSUFDQSxDQUFDLFFBQVEsUUFBUTtBQUFBLEVBQ3JCO0FBQ0EsU0FBTyxDQUFDLFFBQVEsV0FBVyxRQUFRLFVBQVU7QUFDakQ7QUFHTyxTQUFTLGdCQUF3QjtBQUNwQyxRQUFNLGFBQWEsSUFBSSxZQUFZLENBQUM7QUFDcEMsT0FBSyxPQUFPLGdCQUFnQixVQUFVO0FBQ3RDLFNBQU8sV0FBVyxDQUFDLEVBQUUsU0FBUztBQUNsQztBQUdBLGVBQXNCLHFCQUFxQixXQUFzQkEsVUFBa0M7QUFDL0YsTUFBSTtBQUNBLFVBQU0sdUJBQXVCLGtCQUFrQkEsUUFBTztBQUN0RCxVQUFNLG9CQUFpQyxNQUFNLE9BQU8sT0FBTyxPQUFPO0FBQUEsTUFDOUQsRUFBRSxNQUFNLFdBQVc7QUFBQSxNQUNuQjtBQUFBLE1BQ0E7QUFBQSxJQUNKO0FBQ0EsV0FBTywwQkFBMEIsaUJBQWlCO0FBQUEsRUFDdEQsU0FBUyxHQUFHO0FBQ1IsUUFBSSxhQUFhLGNBQWM7QUFBRSxjQUFRLElBQUksQ0FBQztBQUFHLGNBQVEsSUFBSSxvQkFBb0I7QUFBQSxJQUFFLFdBQzFFLGFBQWEsb0JBQW9CO0FBQUUsY0FBUSxJQUFJLGdEQUFnRDtBQUFBLElBQUUsT0FDckc7QUFBRSxjQUFRLElBQUksQ0FBQztBQUFBLElBQUU7QUFDdEIsVUFBTTtBQUFBLEVBQ1Y7QUFDSjtBQUdBLGVBQXNCLG1CQUFtQixZQUF1QkEsVUFBa0M7QUFDOUYsTUFBSTtBQUNBLFVBQU0sdUJBQXVCLGtCQUFrQkEsUUFBTztBQUN0RCxVQUFNLGtCQUErQixNQUFNLE9BQU8sT0FBTyxPQUFPO0FBQUEsTUFDNUQ7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0o7QUFDQSxXQUFPLDBCQUEwQixlQUFlO0FBQUEsRUFDcEQsU0FBUyxHQUFHO0FBQ1IsUUFBSSxhQUFhLGNBQWM7QUFBRSxjQUFRLElBQUksQ0FBQztBQUFHLGNBQVEsSUFBSSxtQkFBbUI7QUFBQSxJQUFFLFdBQ3pFLGFBQWEsb0JBQW9CO0FBQUUsY0FBUSxJQUFJLDhDQUE4QztBQUFBLElBQUUsT0FDbkc7QUFBRSxjQUFRLElBQUksQ0FBQztBQUFBLElBQUU7QUFDdEIsVUFBTTtBQUFBLEVBQ1Y7QUFDSjtBQUlBLGVBQXNCLHNCQUFzQixZQUF1QkEsVUFBa0M7QUFDakcsTUFBSTtBQUNBLFVBQU0scUJBQWtDLE1BQ3BDLE9BQU8sT0FBTyxPQUFPO0FBQUEsTUFDakIsRUFBRSxNQUFNLFdBQVc7QUFBQSxNQUNuQjtBQUFBLE1BQ0EsMEJBQTBCQSxRQUFPO0FBQUEsSUFDckM7QUFDSixXQUFPLGtCQUFrQixrQkFBa0I7QUFBQSxFQUMvQyxTQUFTLEdBQUc7QUFDUixRQUFJLGFBQWEsY0FBYztBQUMzQixjQUFRLElBQUksa0RBQWtEO0FBQUEsSUFDbEUsV0FBVyxhQUFhLG9CQUFvQjtBQUN4QyxjQUFRLElBQUksaURBQWlEO0FBQUEsSUFDakUsTUFDSyxTQUFRLElBQUksbUJBQW1CO0FBQ3BDLFVBQU07QUFBQSxFQUNWO0FBQ0o7QUFJQSxlQUFzQiw2QkFBNkIsV0FBc0JDLGlCQUF3QixlQUF5QztBQUN0SSxNQUFJO0FBQ0EsVUFBTSxzQkFBc0IsMEJBQTBCLGFBQWE7QUFDbkUsVUFBTSw4QkFBOEIsa0JBQWtCQSxlQUFjO0FBQ3BFLFVBQU0sV0FBb0IsTUFDdEIsT0FBTyxPQUFPLE9BQU87QUFBQSxNQUNqQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQTJCO0FBQ25DLFdBQU87QUFBQSxFQUNYLFNBQVMsR0FBRztBQUNSLFFBQUksYUFBYSxjQUFjO0FBQzNCLGNBQVEsSUFBSSw4REFBOEQ7QUFBQSxJQUM5RSxXQUFXLGFBQWEsb0JBQW9CO0FBQ3hDLGNBQVEsSUFBSSxzREFBc0Q7QUFBQSxJQUN0RSxNQUNLLFNBQVEsSUFBSSxtQkFBbUI7QUFDcEMsVUFBTTtBQUFBLEVBQ1Y7QUFDSjtBQUlBLGVBQXNCLHNCQUEwQztBQUM1RCxRQUFNLE1BQWlCLE1BQU0sT0FBTyxPQUFPLE9BQU87QUFBQSxJQUM5QztBQUFBLE1BQ0ksTUFBTTtBQUFBLE1BQ04sUUFBUTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsSUFDQSxDQUFDLFdBQVcsU0FBUztBQUFBLEVBQ3pCO0FBQ0EsU0FBTztBQUNYO0FBR0EsZUFBc0IscUJBQXFCLEtBQWlDO0FBQ3hFLFFBQU0sY0FBMkIsTUFBTSxPQUFPLE9BQU8sT0FBTyxVQUFVLE9BQU8sR0FBRztBQUNoRixTQUFPLDBCQUEwQixXQUFXO0FBQ2hEO0FBR0EsZUFBc0IscUJBQXFCLFlBQXdDO0FBQy9FLE1BQUk7QUFDQSxVQUFNLGlCQUE4QiwwQkFBMEIsVUFBVTtBQUN4RSxVQUFNLE1BQWlCLE1BQU0sT0FBTyxPQUFPLE9BQU87QUFBQSxNQUM5QztBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0EsQ0FBQyxXQUFXLFNBQVM7QUFBQSxJQUFDO0FBQzFCLFdBQU87QUFBQSxFQUNYLFNBQVMsR0FBRztBQUNSLFFBQUksYUFBYSxjQUFjO0FBQUUsY0FBUSxJQUFJLDZDQUE2QztBQUFBLElBQUUsV0FDbkYsYUFBYSxvQkFBb0I7QUFBRSxjQUFRLElBQUksNkNBQTZDO0FBQUEsSUFBRSxPQUNsRztBQUFFLGNBQVEsSUFBSSxDQUFDO0FBQUEsSUFBRTtBQUN0QixVQUFNO0FBQUEsRUFDVjtBQUNKO0FBWUEsZUFBc0Isd0JBQXdCLEtBQWdCRCxVQUFvQztBQUM5RixNQUFJO0FBQ0EsVUFBTSx1QkFBdUIsa0JBQWtCQSxRQUFPO0FBQ3RELFVBQU0sS0FBSyxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDM0QsVUFBTSxTQUFTLDBCQUEwQixFQUFFO0FBQzNDLFVBQU0sb0JBQWlDLE1BQU0sT0FBTyxPQUFPLE9BQU87QUFBQSxNQUM5RCxFQUFFLE1BQU0sV0FBVyxHQUFHO0FBQUEsTUFDdEI7QUFBQSxNQUNBO0FBQUEsSUFDSjtBQUNBLFdBQU8sQ0FBQywwQkFBMEIsaUJBQWlCLEdBQUcsTUFBTTtBQUFBLEVBQ2hFLFNBQVMsR0FBRztBQUNSLFFBQUksYUFBYSxjQUFjO0FBQUUsY0FBUSxJQUFJLENBQUM7QUFBRyxjQUFRLElBQUksb0JBQW9CO0FBQUEsSUFBRSxXQUMxRSxhQUFhLG9CQUFvQjtBQUFFLGNBQVEsSUFBSSxtREFBbUQ7QUFBQSxJQUFFLE9BQ3hHO0FBQUUsY0FBUSxJQUFJLENBQUM7QUFBQSxJQUFFO0FBQ3RCLFVBQU07QUFBQSxFQUNWO0FBQ0o7QUFJQSxlQUFzQix3QkFBd0IsS0FBZ0JBLFVBQWlCLFlBQXFDO0FBQ2hILFFBQU0sb0JBQWlDLDBCQUEwQixVQUFVO0FBQzNFLE1BQUk7QUFDQSxVQUFNLHFCQUFrQyxNQUNwQyxPQUFPLE9BQU8sT0FBTztBQUFBLE1BQ2pCLEVBQUUsTUFBTSxXQUFXLElBQUksa0JBQWtCO0FBQUEsTUFDekM7QUFBQSxNQUNBLDBCQUEwQkEsUUFBTztBQUFBLElBQ3JDO0FBQ0osV0FBTyxrQkFBa0Isa0JBQWtCO0FBQUEsRUFDL0MsU0FBUyxHQUFHO0FBQ1IsUUFBSSxhQUFhLGNBQWM7QUFDM0IsY0FBUSxJQUFJLGtEQUFrRDtBQUFBLElBQ2xFLFdBQVcsYUFBYSxvQkFBb0I7QUFDeEMsY0FBUSxJQUFJLG1EQUFtRDtBQUFBLElBQ25FLE1BQ0ssU0FBUSxJQUFJLG1CQUFtQjtBQUNwQyxVQUFNO0FBQUEsRUFDVjtBQUNKO0FBR0EsZUFBc0IsS0FBSyxNQUErQjtBQUN0RCxRQUFNLGdCQUFnQixrQkFBa0IsSUFBSTtBQUM1QyxRQUFNLGNBQWMsTUFBTSxPQUFPLE9BQU8sT0FBTyxPQUFPLFdBQVcsYUFBYTtBQUM5RSxTQUFPLDBCQUEwQixXQUFXO0FBQ2hEO0FBRUEsSUFBTSxxQkFBTixjQUFpQyxNQUFNO0FBQUU7QUFHekMsU0FBUywwQkFBMEIsYUFBa0M7QUFDakUsTUFBSSxZQUFZLElBQUksV0FBVyxXQUFXO0FBQzFDLE1BQUksYUFBYTtBQUNqQixXQUFTLElBQUksR0FBRyxJQUFJLFVBQVUsWUFBWSxLQUFLO0FBQzNDLGtCQUFjLE9BQU8sYUFBYSxVQUFVLENBQUMsQ0FBQztBQUFBLEVBQ2xEO0FBQ0EsU0FBTyxLQUFLLFVBQVU7QUFDMUI7QUFHQSxTQUFTLDBCQUEwQixRQUE2QjtBQUM1RCxNQUFJO0FBQ0EsUUFBSSxVQUFVLEtBQUssTUFBTTtBQUN6QixRQUFJLFFBQVEsSUFBSSxXQUFXLFFBQVEsTUFBTTtBQUN6QyxhQUFTLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO0FBQ3JDLFlBQU0sQ0FBQyxJQUFJLFFBQVEsV0FBVyxDQUFDO0FBQUEsSUFDbkM7QUFDQSxXQUFPLE1BQU07QUFBQSxFQUNqQixTQUFTLEdBQUc7QUFDUixZQUFRLElBQUksdUJBQXVCLE9BQU8sVUFBVSxHQUFHLEVBQUUsQ0FBQyxpREFBaUQ7QUFDM0csVUFBTSxJQUFJO0FBQUEsRUFDZDtBQUNKO0FBR0EsU0FBUyxrQkFBa0IsS0FBMEI7QUFDakQsTUFBSSxNQUFNLG1CQUFtQixHQUFHO0FBQ2hDLE1BQUksVUFBVSxJQUFJLFdBQVcsSUFBSSxNQUFNO0FBQ3ZDLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUs7QUFDakMsWUFBUSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUM7QUFBQSxFQUNqQztBQUNBLFNBQU87QUFDWDtBQUdBLFNBQVMsa0JBQWtCLGFBQWtDO0FBQ3pELE1BQUksWUFBWSxJQUFJLFdBQVcsV0FBVztBQUMxQyxNQUFJLE1BQU07QUFDVixXQUFTLElBQUksR0FBRyxJQUFJLFVBQVUsWUFBWSxLQUFLO0FBQzNDLFdBQU8sT0FBTyxhQUFhLFVBQVUsQ0FBQyxDQUFDO0FBQUEsRUFDM0M7QUFDQSxTQUFPLG1CQUFtQixHQUFHO0FBQ2pDOzs7QUNsYU8sSUFBTSxjQUFOLE1BQWtCO0FBQUEsRUFDckIsWUFBbUIsVUFBa0I7QUFBbEI7QUFBQSxFQUFvQjtBQUMzQztBQUlPLElBQU0saUJBQU4sTUFBcUI7QUFBQSxFQUN4QixZQUFtQixXQUEwQixPQUFlO0FBQXpDO0FBQTBCO0FBQUEsRUFBaUI7QUFDbEU7QUFHTyxJQUFNLGdCQUFOLE1BQW9CO0FBQUEsRUFDdkIsWUFBbUIsU0FDUixnQkFDQSxPQUNBLGFBQTJCO0FBSG5CO0FBQ1I7QUFDQTtBQUNBO0FBQUEsRUFBNkI7QUFDNUM7QUFHTyxJQUFNLGdCQUFOLE1BQW9CO0FBQUEsRUFDdkIsWUFBbUIsTUFBcUIsSUFBbUIsVUFBa0I7QUFBMUQ7QUFBcUI7QUFBbUI7QUFBQSxFQUFvQjtBQUNuRjtBQUVPLElBQU0sa0JBQU4sTUFBc0I7QUFBQSxFQUN6QixZQUFtQkUsVUFDUixPQUNBLFNBQ0EsU0FBaUI7QUFIVCxtQkFBQUE7QUFDUjtBQUNBO0FBQ0E7QUFBQSxFQUFtQjtBQUNsQztBQUdPLElBQU0sa0JBQU4sTUFBc0I7QUFBQSxFQUN6QixZQUFtQixTQUNSLGdCQUNBLGFBQWdDO0FBRnhCO0FBQ1I7QUFDQTtBQUFBLEVBQWtDO0FBQ2pEO0FBR08sSUFBTSxhQUFOLE1BQWlCO0FBQUEsRUFDcEIsWUFBbUIsU0FBeUIsY0FBc0I7QUFBL0M7QUFBeUI7QUFBQSxFQUF3QjtBQUN4RTtBQUlPLElBQU0sYUFBTixNQUFpQjtBQUFBLEVBQ3BCLFlBQW1CLFFBQXVCQyxXQUF5QixTQUFpQjtBQUFqRTtBQUF1QixvQkFBQUE7QUFBeUI7QUFBQSxFQUFtQjtBQUMxRjtBQUVPLElBQU0sa0JBQU4sTUFBc0I7QUFBQSxFQUN6QixZQUNXLGVBQXVCO0FBQXZCO0FBQUEsRUFBeUI7QUFDeEM7QUFFTyxJQUFNLGlCQUFOLE1BQXFCO0FBQUEsRUFDeEIsWUFBbUIsU0FDZkQsVUFBaUI7QUFERjtBQUFBLEVBQ0k7QUFDM0I7QUFHTyxJQUFNLGFBQU4sTUFBaUI7QUFBQSxFQUNwQixZQUFtQixlQUE4QixXQUEyQixZQUFxQjtBQUE5RTtBQUE4QjtBQUEyQjtBQUFBLEVBQXVCO0FBQ3ZHO0FBRU8sSUFBTSxZQUFOLE1BQWdCO0FBQUEsRUFDbkIsWUFBbUIsU0FBeUIsS0FBb0IsY0FBc0I7QUFBbkU7QUFBeUI7QUFBb0I7QUFBQSxFQUF3QjtBQUM1Rjs7O0FDL0NBLElBQUksQ0FBQyxPQUFPLGdCQUFpQixPQUFNLHFCQUFxQjtBQUd4RCxJQUFJLHFCQUFxQjtBQUV6QixJQUFNLGtCQUFrQixTQUFTLGVBQWUsV0FBVztBQUMzRCxJQUFNLGFBQWEsU0FBUyxlQUFlLGFBQWE7QUFDeEQsSUFBTSxXQUFXLFNBQVMsZUFBZSxVQUFVO0FBQ25ELElBQU1FLFdBQVUsU0FBUyxlQUFlLFNBQVM7QUFDakQsSUFBTSxvQkFBb0IsU0FBUyxlQUFlLG9CQUFvQjtBQUV0RSxJQUFJLGdCQUEwQjtBQUM5QixJQUFJLGNBQXVCO0FBQzNCLElBQUksZUFBd0I7QUFDNUIsSUFBSSxvQkFBNkI7QUFFakMsU0FBUyxtQkFBbUI7QUFDeEIsb0JBQWtCLGNBQWM7QUFDcEM7QUFFQSxTQUFTLGFBQWEsS0FBNkI7QUFDL0MsTUFBSSxVQUFVLFNBQVMsY0FBYyxLQUFLO0FBQzFDLFVBQVEsWUFBWTtBQUNwQixTQUFPO0FBQ1g7QUFFQSxTQUFTLHNCQUFzQkEsVUFBaUI7QUFDNUMsb0JBQWtCLE9BQU8sYUFBYSxtQkFBbUJBLFFBQU8sQ0FBQztBQUNyRTtBQUdBLElBQUksaUJBQWlCO0FBT3JCLGVBQWUsZUFBZ0M7QUFDM0MsUUFBTSxZQUFZLElBQUksZ0JBQWdCLE9BQU8sU0FBUyxNQUFNO0FBQzVELFFBQU0sY0FBYyxNQUFNLE1BQU0sY0FBYyxXQUFXO0FBQUEsSUFDckQsUUFBUTtBQUFBLElBQ1IsU0FBUztBQUFBLE1BQ0wsZ0JBQWdCO0FBQUEsSUFDcEI7QUFBQSxFQUNKLENBQUM7QUFDRCxNQUFJLENBQUMsWUFBWSxJQUFJO0FBQ2pCLFVBQU0sSUFBSSxNQUFNLGtCQUFrQixZQUFZLE1BQU0sRUFBRTtBQUFBLEVBQzFEO0FBQ0EsUUFBTSxhQUFjLE1BQU0sWUFBWSxLQUFLO0FBQzNDLFNBQU8sV0FBVztBQUN0QjtBQUVBLGVBQWUsYUFBYTtBQUN4QixtQkFBaUIsTUFBTSxhQUFhO0FBR3BDLGtCQUFnQixjQUFjO0FBQ2xDO0FBRUEsV0FBVztBQU1YLFNBQVMsZUFBdUI7QUFDNUIsUUFBTSxPQUFPLE9BQU8sU0FBUztBQUM3QixRQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7QUFDakMsU0FBTztBQUNYO0FBRUEsSUFBSSxZQUFZLGFBQWE7QUFFN0IsZUFBZSxTQUFTQyxPQUFjLFdBQW9CLFlBQXlDO0FBTS9GLFFBQU0sb0JBQ0YsSUFBSSxXQUFXQSxPQUFNLFdBQVcsVUFBVTtBQUc5QyxRQUFNLFlBQVksSUFBSSxnQkFBZ0IsT0FBTyxTQUFTLE1BQU07QUFHNUQsUUFBTSxhQUFhLE1BQU0sTUFBTSxhQUFhLFdBQVc7QUFBQSxJQUNuRCxRQUFRO0FBQUEsSUFDUixNQUFNLEtBQUssVUFBVSxpQkFBaUI7QUFBQSxJQUN0QyxTQUFTO0FBQUEsTUFDTCxnQkFBZ0I7QUFBQSxJQUNwQjtBQUFBLEVBQ0osQ0FBQztBQUNELE1BQUksQ0FBQyxXQUFXLElBQUk7QUFDaEIsVUFBTSxJQUFJLE1BQU0sa0JBQWtCLFdBQVcsTUFBTSxFQUFFO0FBQUEsRUFDekQ7QUFDQSxRQUFNLFlBQWEsTUFBTSxXQUFXLEtBQUs7QUFDekMsTUFBSSxDQUFDLFVBQVUsUUFBUyxPQUFNLFVBQVUsWUFBWTtBQUFBLE9BQy9DO0FBQ0QsUUFBSSxhQUFhLFdBQVksUUFBTyxNQUFNLCtCQUErQixVQUFVLEdBQUc7QUFBQSxhQUM3RSxDQUFDLGFBQWEsV0FBWSxRQUFPLE1BQU0sZ0NBQWdDLFVBQVUsR0FBRztBQUFBLGFBQ3BGLGFBQWEsQ0FBQyxXQUFZLFFBQU8sTUFBTSw4QkFBOEIsVUFBVSxHQUFHO0FBQUEsYUFDbEYsQ0FBQyxhQUFhLENBQUMsV0FBWSxRQUFPLE1BQU0sK0JBQStCLFVBQVUsR0FBRztBQUFBLEVBQ2pHO0FBQ0o7QUFFQSxlQUFlLFlBQVksV0FBbUIsY0FBc0JDLGlCQUE2QztBQUM3RyxNQUFJO0FBQ0EsUUFBSSxnQkFDQSxJQUFJLFdBQVcsV0FBVyxjQUFjQSxlQUFjO0FBQzFELFVBQU0sWUFBWSxJQUFJLGdCQUFnQixPQUFPLFNBQVMsTUFBTTtBQUU1RCxVQUFNLFVBQVUsTUFBTSxNQUFNLHFCQUFxQixZQUFZLE1BQU0sV0FBVztBQUFBLE1BQzFFLFFBQVE7QUFBQSxNQUNSLE1BQU0sS0FBSyxVQUFVLGFBQWE7QUFBQSxNQUNsQyxTQUFTO0FBQUEsUUFDTCxnQkFBZ0I7QUFBQSxNQUNwQjtBQUFBLElBQ0osQ0FBQztBQUNELFFBQUksQ0FBQyxRQUFRLElBQUk7QUFDYixZQUFNLElBQUksTUFBTSxrQkFBa0IsUUFBUSxNQUFNLEVBQUU7QUFBQSxJQUN0RDtBQUVBLFdBQVEsTUFBTSxRQUFRLEtBQUs7QUFBQSxFQUMvQixTQUNPLE9BQU87QUFDVixRQUFJLGlCQUFpQixPQUFPO0FBQ3hCLGNBQVEsSUFBSSxtQkFBbUIsTUFBTSxPQUFPO0FBQzVDLGFBQU8sSUFBSSxXQUFXLE9BQU8sTUFBTSxPQUFPO0FBQUEsSUFDOUMsT0FBTztBQUNILGNBQVEsSUFBSSxzQkFBc0IsS0FBSztBQUN2QyxhQUFPLElBQUksV0FBVyxPQUFPLDhCQUE4QjtBQUFBLElBQy9EO0FBQUEsRUFDSjtBQUNKO0FBR0EsZUFBZSxVQUFVO0FBQ3JCLE1BQUk7QUFDQSxVQUFNRCxRQUFPO0FBQ2IsVUFBTSxpQkFDRixJQUFJLGVBQWVBLE9BQU0sa0JBQWtCO0FBQy9DLFVBQU0sWUFBWSxJQUFJLGdCQUFnQixPQUFPLFNBQVMsTUFBTTtBQUM1RCxVQUFNLFVBQVUsTUFBTTtBQUFBLE1BQU0sY0FBYyxZQUFZLE1BQU07QUFBQSxNQUN0RDtBQUFBLFFBQ0UsUUFBUTtBQUFBLFFBQ1IsTUFBTSxLQUFLLFVBQVUsY0FBYztBQUFBLFFBQ25DLFNBQVM7QUFBQSxVQUNMLGdCQUFnQjtBQUFBLFFBQ3BCO0FBQUEsTUFDSjtBQUFBLElBQUM7QUFDTCxRQUFJLENBQUMsUUFBUSxJQUFJO0FBQ2IsWUFBTSxJQUFJLE1BQU0sa0JBQWtCLFFBQVEsTUFBTSxHQUFHO0FBQUEsSUFDdkQ7QUFDQSxVQUFNLFNBQVUsTUFBTSxRQUFRLEtBQUs7QUFDbkMsUUFBSSxDQUFDLE9BQU8sU0FBUztBQUFFLFlBQU0sT0FBTyxjQUFjO0FBQUEsSUFBRSxPQUMvQztBQUVELDJCQUFxQixPQUFPO0FBQzVCLFVBQUksT0FBTyxZQUFZLFVBQVUsR0FBRztBQUNoQyxpQkFBUyxLQUFLLE9BQU8sYUFBYTtBQUM5QixjQUFJLENBQUMsR0FBRyxNQUFPLFFBQVFFLFdBQVUsWUFBWSxPQUFPLGdCQUFnQixJQUFJLE1BQU0sZUFBZSxDQUFDO0FBQzlGLGNBQUksS0FBTSxRQUFRLEdBQUk7QUFBRSwyQkFBZSxjQUFjO0FBQUksNkJBQWlCLEdBQUdGLE9BQU0sUUFBUSxJQUFJLFlBQVk7QUFBQSxVQUFDLFdBR25HLEtBQU0sUUFBUSxHQUFJO0FBQUMsNEJBQWdCLE1BQU0sY0FBYztBQUFBLFVBQUssV0FHNUQsS0FBSyxhQUFhLE9BQU8sWUFBWSxLQUFNLFFBQVEsR0FBSTtBQUFFLCtCQUFtQixRQUFRRSxXQUFVLFVBQVUsR0FBRyxpQkFBaUIsR0FBR0YsT0FBTSxRQUFRLElBQUksa0JBQWlCLEVBQUU7QUFBQSxVQUFDLFdBR3JLLEtBQU0sUUFBUSxHQUFJO0FBQUUsb0JBQVEsSUFBSSxVQUFVO0FBQUksK0JBQW1CLFFBQVFFLFdBQVUsVUFBVTtBQUFBLFVBQUMsV0FHOUYsS0FBTSxRQUFRLEtBQU0sYUFBYSxPQUFNLGlCQUFpQixHQUFHO0FBQUUsb0JBQVEsSUFBSSx3QkFBd0I7QUFBQSxVQUFFLE1BRXZHLFNBQVEsSUFBSSxTQUFTLEVBQUUsU0FBUyxTQUFTLEVBQUUsV0FBVyxRQUFRLEVBQUUsVUFBVSw2QkFBNkJGLEtBQUk7QUFBQSxRQUVwSDtBQUFBLE1BQ0o7QUFBQSxJQUNKO0FBQUEsRUFDSixTQUNPLE9BQU87QUFDVixRQUFJLGlCQUFpQixPQUFPO0FBQ3hCLGNBQVEsSUFBSSxtQkFBbUIsTUFBTSxPQUFPO0FBQzVDLGFBQU8sTUFBTTtBQUFBLElBQ2pCLE9BQU87QUFDSCxjQUFRLElBQUksc0JBQXNCLEtBQUs7QUFDdkMsYUFBTztBQUFBLElBQ1g7QUFBQSxFQUNKO0FBQ0o7QUFHQSxJQUFNLGtCQUFrQixZQUFZLFNBQVMsR0FBSTtBQU1qRCxXQUFXLFVBQVUsaUJBQWtCO0FBQ25DLFVBQVEsSUFBSSxpQkFBaUI7QUFDN0IsTUFBSSxZQUFZO0FBQ2hCLE1BQUksZUFBZSxTQUFTO0FBQzVCLE1BQUksSUFBSTtBQUNSLG1CQUFpQixHQUFFLFdBQVcsY0FBYyxPQUFPLEVBQUU7QUFDckQsVUFBUSxJQUFJLFNBQVM7QUFFckIsU0FBTyxJQUFJLE1BQU0saUJBQWlCLE9BQU87QUFDckMsVUFBTSxJQUFJLFFBQVEsYUFBVyxXQUFXLFNBQVMsR0FBSyxDQUFDO0FBQ3ZELFlBQVEsSUFBSSx3QkFBd0I7QUFDcEM7QUFBQSxFQUNKO0FBQ0EsTUFBSTtBQUVKLE1BQUksaUJBQWlCLE1BQUs7QUFDdEIsWUFBUSxJQUFJLG9CQUFvQixXQUFXO0FBQzNDLHdCQUFvQixjQUFjO0FBQ2xDLHFCQUFpQixHQUFFLFdBQVcsY0FBY0QsU0FBUSxPQUFPLGFBQWEsaUJBQWlCO0FBQ3pGLG9CQUFnQixHQUFHLFdBQVcsY0FBY0EsU0FBUSxPQUFPLFdBQVc7QUFDdEUsWUFBUSxJQUFJLFNBQVM7QUFBQSxFQUN6QjtBQUVBLE1BQUk7QUFHSixnQkFBYztBQUNkLGtCQUFnQjtBQUNwQjtBQUVBLGVBQWUsZ0JBQWlCLGFBQXNCLFdBQW9CLGNBQXVCQSxVQUFrQixPQUFnQjtBQUMvSCxNQUFJLG1CQUFtQixLQUFLLFVBQVUsQ0FBQyxhQUFhLFdBQVcsY0FBY0EsVUFBUyxLQUFLLENBQUM7QUFFNUYsUUFBTSxLQUFLLE1BQU0sU0FBUyxXQUFXLE1BQU0sSUFBSTtBQUMvQyxRQUFNLG1CQUFtQixNQUFNLHFCQUFxQixJQUFJLGdCQUFnQjtBQUN4RSxRQUFNLGFBQWEsTUFBTSxZQUFZLFdBQVcsV0FBVyxnQkFBZ0I7QUFFM0UsTUFBSSxDQUFDLFdBQVcsU0FDWjtBQUFDLFlBQVEsSUFBSSxXQUFXLFlBQVk7QUFBQSxFQUFDLE9BRWhDO0FBQ0wsWUFBUSxJQUFJLG9CQUFvQjtBQUFBLEVBQ3BDO0FBR0o7QUFFQSxlQUFlLGlCQUFpQixhQUFzQixXQUFvQixjQUF1QkEsVUFBa0IsT0FBZ0JJLHFCQUE2QixJQUFJO0FBRWhLLE1BQUksbUJBQW1CLEtBQUssVUFBVSxDQUFDLGFBQWEsV0FBVyxjQUFjSixVQUFTLE9BQU9JLGtCQUFpQixDQUFDO0FBQy9HLE1BQUk7QUFPQSxVQUFNLEtBQUssTUFBTSxTQUFTLGNBQWMsTUFBTSxJQUFJO0FBRWxELFVBQU0sbUJBQW1CLE1BQU0scUJBQXFCLElBQUksZ0JBQWdCO0FBRXhFLFVBQU0sYUFBYSxNQUFNLFlBQVksV0FBVyxjQUFjLGdCQUFnQjtBQUU5RSxRQUFJLENBQUMsV0FBVyxRQUFTLFNBQVEsSUFBSSxXQUFXLFlBQVk7QUFBQSxTQUN2RDtBQUNELGNBQVEsSUFBSSxnQ0FBZ0M7QUFBQSxJQUNoRDtBQUFBLEVBQ0osU0FBUyxHQUFHO0FBQ0osUUFBSSxhQUFhLE9BQU87QUFDcEIsY0FBUSxJQUFJLG1CQUFtQixFQUFFLE9BQU87QUFBQSxJQUM1QyxPQUFPO0FBQ0gsY0FBUSxJQUFJLHNCQUFzQixDQUFDO0FBQUEsSUFDdkM7QUFBQSxFQUVSO0FBRUo7QUFJQSxTQUFTLGVBQXVCO0FBQzVCLFFBQU0sTUFBTSxvQkFBSSxLQUFLO0FBQ3JCLFFBQU0sUUFBUSxJQUFJLFNBQVMsRUFBRSxTQUFTO0FBQ3RDLFFBQU0sVUFBVSxJQUFJLFdBQVcsRUFBRSxTQUFTO0FBQzFDLFFBQU0sVUFBVSxJQUFJLFdBQVcsRUFBRSxTQUFTO0FBRzFDLFNBQU8sR0FBSSxNQUFNLFdBQVcsSUFBSyxNQUFNLFFBQVEsS0FBSyxJQUFLLFFBQVEsV0FBVyxJQUFLLE1BQU0sVUFBVSxPQUFPLElBQUssUUFBUSxXQUFXLElBQUssTUFBTSxVQUFVLE9BQU87QUFDaEs7QUFNQSxlQUFlLGVBQWUsU0FBeUY7QUFDbkgsUUFBTSxPQUFPO0FBQ2IsTUFBSTtBQUNBLFVBQU0sZ0JBQWdCLFFBQVE7QUFDOUIsVUFBTSxpQkFBaUIsUUFBUTtBQUMvQixRQUFJLFFBQVEsYUFBYSxNQUFNO0FBRTNCLGFBQU8sQ0FBQyxPQUFPLEdBQUcsSUFBSSxJQUFJLElBQUcsSUFBSSxFQUFFO0FBQUEsSUFDdkMsT0FDSztBQUNELFVBQUk7QUFFQSxjQUFNLFVBQVUsTUFBTSxTQUFTLE1BQU0sT0FBTyxJQUFJO0FBQ2hELGNBQU0sdUJBQXVCLE1BQU0sc0JBQXNCLFNBQVMsY0FBYztBQUVoRixjQUFNLHNCQUFzQixLQUFLLE1BQU0sb0JBQW9CO0FBRTNELGNBQU0sdUJBQXVCLE9BQU8sb0JBQW9CLENBQUMsQ0FBQztBQUMxRCxjQUFNLHlCQUF5QixvQkFBb0IsQ0FBQztBQUNwRCxjQUFNLDJCQUEyQixvQkFBb0IsQ0FBQztBQUN0RCxjQUFNLGlCQUFpQixvQkFBb0IsQ0FBQztBQUM1QyxjQUFNLGlCQUFrQixvQkFBb0IsQ0FBQztBQUM3QyxjQUFNLDZCQUE4QixvQkFBb0IsQ0FBQztBQUV6RCxZQUFJLDBCQUEwQixpQkFBaUIsNEJBQTRCLGdCQUFnQjtBQUN2RixpQkFBTyxDQUFDLE1BQU0sc0JBQXNCLHdCQUF3QiwwQkFBMEIsS0FBSywwQkFBMEIsaUJBQWlCLEdBQUcsR0FBRyxnQkFBZ0IsMEJBQTBCO0FBQUEsUUFDMUwsT0FDSztBQUNELGtCQUFRLElBQUksNEVBQTRFO0FBQUEsUUFDNUY7QUFBQSxNQUNKLFNBQVMsR0FBRztBQUNSLGdCQUFRLElBQUksa0RBQWtELENBQUM7QUFDL0QsZUFBTyxDQUFDLE9BQU8sSUFBSyxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUU7QUFBQSxNQUMxQztBQUFBLElBQ0o7QUFBQSxFQUNKLFNBQVMsR0FBRztBQUNSLFlBQVEsSUFBSSxrREFBa0QsQ0FBQztBQUMvRCxXQUFPLENBQUMsT0FBTyxHQUFHLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtBQUFBLEVBQ3hDO0FBQ0o7QUFHQSxTQUFTLG1CQUFtQixPQUFlLEtBQWFGLGlCQUF3QjtBQUM1RSxRQUFNRCxRQUFPO0FBQ2IsVUFBUSxJQUFJLHlCQUF5QixRQUFRLFNBQVMsTUFBTSxRQUFRQyxlQUFjO0FBQ2xGLE1BQUksVUFBVUQsT0FBTTtBQUNoQixZQUFRLElBQUksZ0RBQTZDO0FBQ3pELFVBQU0sWUFBWSx1QkFBdUIsS0FBSyxPQUFPLEdBQUcsTUFBTUMsZUFBYztBQUM1RSwwQkFBc0IsU0FBUztBQUFBLEVBQ25DLE9BQ0s7QUFDRCxZQUFRLElBQUksd0NBQXdDO0FBQ3BELFVBQU0sWUFBWSxHQUFHLEtBQUssT0FBTyxHQUFHLE1BQU1BLGVBQWM7QUFDeEQsMEJBQXNCLFNBQVM7QUFBQSxFQUNuQztBQUVKO0FBR0EsU0FBUyxhQUFhLGdCQUF3QixrQkFBbUM7QUFDN0UsU0FBTyxPQUFPLGNBQWMsS0FBSyxPQUFPLGdCQUFnQjtBQUU1RDsiLAogICJuYW1lcyI6IFsibWVzc2FnZSIsICJtZXNzYWdlSW5DbGVhciIsICJtZXNzYWdlIiwgInJlY2VpdmVyIiwgIm1lc3NhZ2UiLCAidXNlciIsICJtZXNzYWdlQ29udGVudCIsICJyZWNlaXZlciIsICJjb25maXJtYXRpb25Ob3VjZSJdCn0K
