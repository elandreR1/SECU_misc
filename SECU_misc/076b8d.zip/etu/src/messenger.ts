// Version actuelle du protocole:
// A -> B : {"hey"}pkB
// B -> A : { Nb }pkA
// A -> B : { secret, Nb, Na }pkB
// B -> A : { Na }pkA


import {
    encryptWithPublicKey, decryptWithPrivateKey, stringToPrivateKeyForEncryption, stringToPublicKeyForEncryption,
    stringToPrivateKeyForSignature,
    stringToPublicKeyForSignature, privateKeyToString, hash,
    generateNonce
} from './libCrypto'        //les fonctions pour chiffrer/déchiffrer

import {
    HistoryAnswer, HistoryRequest, KeyRequest, KeyResult, CasUserName, ExtMessage, SendResult,

} from './serverMessages'

// To detect if we can use window.crypto.subtle
if (!window.isSecureContext) alert("Not secure context!")

//Index of the last read message
let lastIndexInHistory = 0

const userButtonLabel = document.getElementById("user-name") as HTMLLabelElement
const sendButton = document.getElementById("send-button") as HTMLButtonElement
const receiver = document.getElementById("receiver") as HTMLInputElement
const message = document.getElementById("message") as HTMLInputElement
const received_messages = document.getElementById("exchanged-messages") as HTMLLabelElement

let receiveNounce : boolean = false
let nouceGlobal : string = ""
let currentNouce : string = ""
let confirmationNouce : string = ""

function clearingMessages() {
    received_messages.textContent = ""
}

function stringToHTML(str: string): HTMLDivElement {        //transforme une chaine de caractères en un élément div html
    var div_elt = document.createElement('div')
    div_elt.innerHTML = str
    return div_elt
}

function addingReceivedMessage(message: string) {
    received_messages.append(stringToHTML('<p></p><p></p>' + message))
}

/* Name of the user of the application... can be Alice/Bob for attacking purposes */
let globalUserName = ""

// WARNING!
// It is necessary to pass the URL parameters, called `urlParams` below, to 
// every GET/POST query you send to the server. This is mandatory to have the possibility 
// to use alternative identities like alice@univ-rennes.fr, bob@univ-rennes.fr, etc. 
// for debugging purposes.
async function fetchCasName(): Promise<string> {
    const urlParams = new URLSearchParams(window.location.search);
    const namerequest = await fetch("/getuser?" + urlParams, {
        method: "GET",
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    });
    if (!namerequest.ok) {
        throw new Error(`Error! status: ${namerequest.status}`);
    }
    const nameResult = (await namerequest.json()) as CasUserName;
    return nameResult.username
}

async function setCasName() {
    globalUserName = await fetchCasName()
    // We replace the name of the user of the application as the default name
    // In the window
    userButtonLabel.textContent = globalUserName
}

setCasName()

/* Name of the owner/developper of the application, i.e, the name of the folder 
   where the web page of the application is stored. E.g, for teachers' application
   this name is "ens" */

function getOwnerName(): string {
    const path = window.location.pathname
    const name = path.split("/", 2)[1]
    return name
}

let ownerName = getOwnerName()

async function fetchKey(user: string, publicKey: boolean, encryption: boolean): Promise<CryptoKey> {
    // Getting the public/private key of user.
    // For public key the boolean 'publicKey' is true.
    // For private key the boolean 'publicKey' is false.
    // If the key is used for encryption/decryption then the boolean 'encryption' is true.
    // If the key is used for signature/signature verification then the boolean is false.
    const keyRequestMessage =
        new KeyRequest(user, publicKey, encryption)
    // For CAS authentication we need to add the authentication ticket
    // It is contained in urlParams
    const urlParams = new URLSearchParams(window.location.search);
    // For getting a key we do not need the ownerName param
    // Because keys are independant of the applications
    const keyrequest = await fetch("/getKey?" + urlParams, {
        method: "POST",
        body: JSON.stringify(keyRequestMessage),
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    });
    if (!keyrequest.ok) {
        throw new Error(`Error! status: ${keyrequest.status}`);
    }
    const keyResult = (await keyrequest.json()) as KeyResult;
    if (!keyResult.success) alert(keyResult.errorMessage)
    else {
        if (publicKey && encryption) return await stringToPublicKeyForEncryption(keyResult.key)
        else if (!publicKey && encryption) return await stringToPrivateKeyForEncryption(keyResult.key)
        else if (publicKey && !encryption) return await stringToPublicKeyForSignature(keyResult.key)
        else if (!publicKey && !encryption) return await stringToPrivateKeyForSignature(keyResult.key)
    }
}

async function sendMessage(agentName: string, receiverName: string, messageContent: string): Promise<SendResult> {
    try {
        let messageToSend =
            new ExtMessage(agentName, receiverName, messageContent)
        const urlParams = new URLSearchParams(window.location.search);

        const request = await fetch("/sendingMessage/" + ownerName + "?" + urlParams, {
            method: "POST",
            body: JSON.stringify(messageToSend),
            headers: {
                "Content-type": "application/json; charset=UTF-8"
            }
        });
        if (!request.ok) {
            throw new Error(`Error! status: ${request.status}`);
        }
        // Dealing with the answer of the message server
        return (await request.json()) as SendResult
    }
    catch (error) {
        if (error instanceof Error) {
            console.log('error message: ', error.message);
            return new SendResult(false, error.message)
        } else {
            console.log('unexpected error: ', error);
            return new SendResult(false, 'An unexpected error occurred')
        }
    }
}

// function for refreshing the content of the window (automatic or manual see below)
async function refresh() {
    try {
        const user = globalUserName
        const historyRequest =
            new HistoryRequest(user, lastIndexInHistory)
        const urlParams = new URLSearchParams(window.location.search);
        const request = await fetch("/history/" + ownerName + "?" + urlParams
            , {
                method: "POST",
                body: JSON.stringify(historyRequest),
                headers: {
                    "Content-type": "application/json; charset=UTF-8"
                }
            });
        if (!request.ok) {
            throw new Error(`Error! status: ${request.status} `);
        }
        const result = (await request.json()) as HistoryAnswer
        if (!result.success) { alert(result.failureMessage) }
        else {
            // This is the place where you can perform trigger any operations for refreshing the page
            lastIndexInHistory = result.index
            if (result.allMessages.length != 0) {
                for (var m of result.allMessages) {         //pour chaque message m
                    let [b, type , sender, receiver, msgContent, nouce, nounceOfReceiver] = await analyseMessage(m)
                    if (b && (type == 1)) { currentNouce = generateNonce() ; constructMessage(2, user, sender, "", currentNouce)}       //partie 1
                    //quand B reçoit le "hey" de A, il génère un nonce qu'il lui envoie

                    else if (b && (type == 2)) {receiveNounce = true, nouceGlobal = nouce}                              //partie 2
                    //on set le nonce comme variable globale et on update la réception du nonce côté A

                    else if (b && verifyNounce(nouce, currentNouce) && (type == 3)) { actionOnMessageOne(sender, receiver, msgContent), selfSaveHistory(4, sender, receiver, msgContent, nouce) ,constructMessage(5, user, sender, "", nounceOfReceiver,"")}     //partie 3
                    //si B reçoit le même nonce que celui qu'il a généré, il authentifie A et peut considérer le message secret reçu.

                    else if (b && (type == 4)) { console.log("Historic") ; actionOnMessageOne(sender, receiver, msgContent)}        //partie 4
                    //pour l'historique 

                    else if (b && (type == 5) && verifyNounce(nouce,confirmationNouce)) { console.log("Confirmation Reception") }

                    else console.log("Msg " + m.sender + " -> " + m.receiver + " : " + m.content + " cannot be exploited by " + user) 
                    //si imprévu/erreur
                }
            }
        }
    }
    catch (error) {
        if (error instanceof Error) {
            console.log('error message: ', error.message);
            return error.message;
        } else {
            console.log('unexpected error: ', error);
            return 'An unexpected error occurred';
        }
    }
}

// Automatic refresh
const intervalRefresh = setInterval(refresh, 2000)

//--------- Début de notre code --------------------------------------------------

//      COTE SENDER
//envoi du message quand on clique sur send
sendButton.onclick = async function () {
    console.log("Boutton clicked")
    let agentName = globalUserName      //nom du sender alice
    let receiverName = receiver.value      //nom du receveur bob
    let i = 0;
    constructMessage(1,agentName, receiverName, "hey", "")      //A initie le protocole en envoyant "hey" à B
    console.log("Proto 1")

    while (i < 10 && receiveNounce == false) {                  //attente de réception du nonce généré par B
        await new Promise(resolve => setTimeout(resolve, 20000)); 
        console.log("Waiting for the nounce")
        i++;
    }
    i = 0;

    if (receiveNounce == true){             //quand on a reçu le nonce
        console.log("Nounce received" + nouceGlobal)
        confirmationNouce = generateNonce()        //A génère un nonce qu'il envoie à B pour confirmer la réception du nonce
        constructMessage(3,agentName, receiverName, message.value, nouceGlobal, confirmationNouce)     //A envoie à B le secret ainsi que le nonce qu'il vient de recevoir
        selfSaveHistory(4, agentName, receiverName, message.value, nouceGlobal)     //A sauvegarde le message envoyé dans son historique
        console.log("Proto 3")
    }

    i = 0;


    nouceGlobal = "";               //reset de réception du nonce (chaque message échangé génère un nouveau nonce)
    receiveNounce = false
}

async function selfSaveHistory (messageType : number, agentName : string, receiverName : string, message : string, nouce : string) {    //historique des messages
    let contentToEncrypt = JSON.stringify([messageType ,agentName, receiverName, message, nouce]) 

    const ka = await fetchKey(globalUserName, true, true) 
    const encryptedMessage = await encryptWithPublicKey(ka, contentToEncrypt)
    const sendResult = await sendMessage(globalUserName, globalUserName, encryptedMessage)

    if (!sendResult.success) 
        {console.log(sendResult.errorMessage)}
    
        else {
        console.log("Successfully save!")
    }
            
    
}

async function constructMessage(messageType : number, agentName : string, receiverName : string, message : string, nouce : string, confirmationNouce : string = "") {   //messageType = 1,2,3,4,5
    
    let contentToEncrypt = JSON.stringify([messageType ,agentName, receiverName, message, nouce, confirmationNouce])   //[alice, bob, m]
    try {
        //
        // "Getting the public/private key of user.
        // For public key the boolean 'publicKey' is true.
        // For private key the boolean 'publicKey' is false.
        // If the key is used for encryption/decryption then the boolean 'encryption' is true.
        // If the key is used for signature/signature verification then the boolean is false.""
        const kb = await fetchKey(receiverName, true, true) //clé publique et encryption donc true, true
        // on chiffre m
        const encryptedMessage = await encryptWithPublicKey(kb, contentToEncrypt)
        // on envoie m
        const sendResult = await sendMessage(agentName, receiverName, encryptedMessage)

        if (!sendResult.success) console.log(sendResult.errorMessage)
        else {
            console.log("Successfully sent the message!")
        }
    } catch (e) {
            if (e instanceof Error) {
                console.log('error message: ', e.message)
            } else {
                console.log('unexpected error: ', e);
            }
            
    }
        
}

// Returning a string representing the current time in the format
// HH:MM:SS
function readableTime(): string {
    const now = new Date()
    const hours = now.getHours().toString()
    const minutes = now.getMinutes().toString()
    const seconds = now.getSeconds().toString()
    // Since getHours() etc return a decimal count for hours, etc. we explicitely add 0 when there
    // are no tens digit.
    return `${(hours.length === 1) ? "0" + hours : hours}:${(minutes.length === 1) ? "0" + minutes : minutes}:${(seconds.length === 1) ? "0" + seconds : seconds}`
}

//--------------------
//COTE RECEIVER
//--------------------
//quand le receveur reçoit le message
async function analyseMessage(message: ExtMessage): Promise<[boolean, number, string ,string, string, string, string]> {
    const user = globalUserName
    try {
        const messageSender = message.sender
        const messageContent = message.content
        if (message.receiver !== user) {
            // If the message is not sent to the user, we do not consider it
            return [false, 0 ,"", "", "","", ""]
        }
        else {
            try {
                //on récup la clé privée de b pour déchiffrer -> false, true
                const privkey = await fetchKey(user, false, true)
                const messageInClearString = await decryptWithPrivateKey(privkey, messageContent)       //on récup (number, string, string, string, string)

                const messageArrayInClear = JSON.parse(messageInClearString) as string[]        //on parse le tout et on isole chaque élément
                                                                                                
                const messageTypeInMessage = Number(messageArrayInClear[0])         //ici le type (définit l'étape du protocole)
                const messageSenderInMessage = messageArrayInClear[1]       //sender = alice dans l'exemple
                const messageReceiverInMessage = messageArrayInClear[2]           //receiver = bob   
                const messageInClear = messageArrayInClear[3]           //message = m
                const nouceInMessage = (messageArrayInClear[4])         //et le nonce
                const confirmationNouceInMessage = (messageArrayInClear[5])         //et le nonce de confirmation

                if (messageSenderInMessage == messageSender || messageReceiverInMessage == globalUserName) {      //si le sender est le même dans le message et dans le tableau c'est good
                    return [true, messageTypeInMessage ,messageSenderInMessage, messageReceiverInMessage, eval("`(${readableTime()}) " + messageInClear + "`"), nouceInMessage, confirmationNouceInMessage]   //on renvoie le message en clair
                }   //est-ce qu'on peut trouver une alternative simple au eval ?
                else {
                    console.log("Real message sender and message sender name in the message do not coincide")
                }
            } catch (e) {
                console.log("analyseMessage: decryption failed because of " + e)
                return [false, -1 , "", "", "", "", ""]
            }
        }
    } catch (e) {
        console.log("analyseMessage: decryption failed because of " + e)
        return [false, 0, "", "", "", "", ""]
    }
}

  
function actionOnMessageOne(fromA: string, ToB: string, messageContent: string) {
    const user = globalUserName         
    console.log("actionOnMessageOne: " + fromA + " -> " + ToB + " : " + messageContent)
    if (fromA === user) {
        console.log("Le message vient de l'utilisateur lui-même.")
        const textToAdd = `<font color="blue"> ${fromA} -> ${ToB} : ${messageContent} </font>`
        addingReceivedMessage(textToAdd)
    }
    else {
        console.log("Message venant d'un autre utilisateur.")
        const textToAdd = `${fromA} -> ${ToB} : ${messageContent} `
        addingReceivedMessage(textToAdd)
    }
    
}
 

function verifyNounce(nounceOfSender: string, nounceOfReceiver: string): boolean {
    return Number(nounceOfSender) == Number(nounceOfReceiver) ;

}



